LEIA PRIMEIRO: GITHUB BUILD

Siga o arquivo GITHUB_BUILD.md para enviar o conteúdo desta pasta a um repositório GitHub e iniciar a compilação na nuvem.
O arquivo .github/workflows/build.yml configura a tentativa automática de build.
Nenhum JAR foi compilado ou testado por este pacote.
