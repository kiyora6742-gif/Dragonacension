package com.dragonascension.proxy;

public class CommonProxy {
    public void preInit() { }
    public void init() { }
}
