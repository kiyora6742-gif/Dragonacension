package com.dragonascension.proxy;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() { super.preInit(); }

    @Override
    public void init() { super.init(); }
}
