package com.dragonascension.command;

import com.dragonascension.core.EvolutionDefinition;
import com.dragonascension.core.EvolutionRegistry;
import com.dragonascension.core.EvolutionValidator;
import com.dragonascension.core.EvolutionUnlockService;
import com.dragonascension.core.PlayerEvolutionData;
import com.dragonascension.event.PlayerDataEvents;
import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.compat.TransformationReadResult;
import com.dragonascension.compat.PlayerContext;
import java.util.Collection;
import java.util.Locale;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;

public class CommandDragonAscension extends CommandBase {
    public String getCommandName() { return "dragonascension"; }
    public String getCommandUsage(ICommandSender sender) {
        return "/dragonascension list|tree|progress|check|masteryinfo|transformation|info|status|context|setrace|mastery|training|challenge|unlock|audit|compat";
    }
    public int getRequiredPermissionLevel() { return 2; }

    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length == 0) {
            help(sender);
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if ("compat".equals(sub)) {
            msg(sender, "Diagnóstico de compatibilidade (v0.8.1):");
            msg(sender, "Minecraft/Forge alvo: 1.7.10 / 10.13.4.1614.");
            msg(sender, "DragonBlockC detectado: " + IntegrationManager.isDragonBlockCPresent()
                    + " | classe API visível: " + IntegrationManager.isDragonBlockCApiClassVisible());
            msg(sender, "JRMCore detectado: " + IntegrationManager.isJRMCorePresent()
                    + " | classe API visível: " + IntegrationManager.isJRMCoreApiClassVisible());
            msg(sender, "DBC Additions detectado: " + IntegrationManager.isAdditionsPresent()
                    + " | classes API visíveis: " + IntegrationManager.isAdditionsApiClassVisible());
            msg(sender, "Adaptador de contexto registrado: " + IntegrationManager.isPlayerContextAdapterRegistered());
            msg(sender, "Adaptador de contexto disponível: " + IntegrationManager.hasPlayerContextAdapter());
            msg(sender, "Adaptador de transformação registrado: " + IntegrationManager.isTransformationAdapterRegistered());
            msg(sender, "Adaptador de transformação disponível: " + IntegrationManager.hasTransformationAdapter());
            msg(sender, "Adaptador de energia registrado: " + (IntegrationManager.getPlayerEnergyProviderId() != null));
            msg(sender, "Provedor de energia: " + (IntegrationManager.getPlayerEnergyProviderId() == null ? "nenhum (ponte JRMCore experimental indisponível)" : IntegrationManager.getPlayerEnergyProviderId()));
            msg(sender, "Provedor de transformação: " +
                    (IntegrationManager.getTransformationProviderId() == null
                    ? "nenhum" : IntegrationManager.getTransformationProviderId()));
            msg(sender, "Classe visível não garante assinatura ou comportamento compatível.");
            msg(sender, "Contexto JRMCore e formas mapeadas do Additions são opcionais; leitura nativa DBC e escrita de energia permanecem experimentais.");
            msg(sender, "IDs externos que não existam na árvore interna são descartados; estados nativos não confirmados não geram domínio.");
            return;
        }
        if ("transformation".equals(sub)) {
            EntityPlayer target = args.length >= 2 ? findPlayer(args[1]) :
                    (sender instanceof EntityPlayer ? (EntityPlayer)sender : null);
            if (target == null) {
                msg(sender, "Jogador não encontrado. Use /dragonascension transformation <jogador>.");
                return;
            }
            PlayerEvolutionData data = PlayerDataEvents.get(target);
            String active = data.getActiveTransformationId();
            msg(sender, "Sessão registrada de " + target.getCommandSenderName() + ": "
                    + (active == null || active.length() == 0 ? "nenhuma" : active));
            msg(sender, "Callbacks de uso confirmados: " + data.getConfirmedTransformationUseEvents());
            TransformationReadResult external = IntegrationManager.readTransformation(target);
            String externalText;
            if (external.getStatus() == TransformationReadResult.Status.ACTIVE) {
                externalText = external.getEvolutionId();
            } else if (external.getStatus() == TransformationReadResult.Status.INACTIVE) {
                externalText = "nenhuma (adaptador confirmou estado normal)";
            } else {
                externalText = "indeterminada (leitura indisponível ou estado não mapeado)";
            }
            msg(sender, "Forma externa reconhecida: " + externalText);
            msg(sender, "Provedor: " +
                    (IntegrationManager.getTransformationProviderId() == null
                    ? "indisponível" : IntegrationManager.getTransformationProviderId()));
            msg(sender, "A sessão salva e a leitura externa são exibidas separadamente para facilitar testes.");
            return;
        }
        if ("audit".equals(sub)) {
            java.util.List<String> errors = EvolutionRegistry.audit();
            if (errors.isEmpty()) {
                msg(sender, "Árvore válida: " + EvolutionRegistry.all().size() + " definições, sem erros estruturais.");
            } else {
                msg(sender, "Foram encontrados " + errors.size() + " problemas:");
                for (String error : errors) msg(sender, error);
            }
            return;
        }
        if ("info".equals(sub) && args.length == 2) {
            EvolutionDefinition d = EvolutionRegistry.get(args[1]);
            if (d == null) { msg(sender, "Evolução desconhecida: " + args[1]); return; }
            msg(sender, d.getDisplayName() + " [" + d.getId() + "]");
            msg(sender, "Raça interna: " + d.getRaceKey() + " | pai: " +
                    (d.getParentId() == null ? "nenhum" : d.getParentId()));
            msg(sender, "Nível: " + d.getRequiredLevel() + " | domínio exigido: " +
                    d.getRequiredMastery() + " | treino: " + d.requiresTraining() +
                    " | desafio: " + d.requiresChallenge());
            return;
        }
        if ("list".equals(sub)) {
            Collection<EvolutionDefinition> all = EvolutionRegistry.all();
            sender.addChatMessage(new ChatComponentText("§6Dragon Ascension §7- " + all.size() + " evoluções:"));
            for (EvolutionDefinition d : all)
                sender.addChatMessage(new ChatComponentText("§e" + d.getId() + " §7- " + d.getDisplayName()));
            return;
        }
        if ("tree".equals(sub) && args.length == 2) {
            String race = args[1].toLowerCase(Locale.ROOT);
            Collection<EvolutionDefinition> definitions = EvolutionRegistry.byRace(race);
            if (definitions.isEmpty()) {
                msg(sender, "Raça desconhecida ou sem evoluções. Use: saiyan, half_saiyan, arcosian, namekian, human, majin.");
                return;
            }
            msg(sender, "Árvore " + race + " — " + definitions.size() + " evoluções:");
            for (EvolutionDefinition d : definitions) {
                String prefix = d.getParentId() == null ? " raiz" : " <- " + d.getParentId();
                msg(sender, d.getId() + prefix + " | domínio: " + d.getRequiredMastery()
                        + " | nível: " + d.getRequiredLevel()
                        + (d.requiresTraining() ? " | treino" : "")
                        + (d.requiresChallenge() ? " | desafio" : ""));
            }
            return;
        }
        if ("context".equals(sub)) {
            EntityPlayer target = args.length >= 2 ? findPlayer(args[1]) :
                    (sender instanceof EntityPlayer ? (EntityPlayer)sender : null);
            if (target == null) { msg(sender, "Jogador não encontrado. Use /dragonascension context <jogador>."); return; }
            PlayerContext context = IntegrationManager.readPlayerContext(target);
            if (context == null) {
                msg(sender, "Contexto externo indisponível: nenhum adaptador DBC/JRMCore verificado foi registrado.");
                return;
            }
            msg(sender, "Provedor: " + context.getProvider());
            msg(sender, "Raça: " + (context.hasRace() ? context.getRaceKey() : "desconhecida"));
            msg(sender, "Nível: " + (context.hasLevel() ? context.getLevel().toString() : "indisponível"));
            msg(sender, "Energia: " + (context.hasEnergy() ? context.getEnergy().toString() : "indisponível"));
            return;
        }
        if ("check".equals(sub) && args.length == 3) {
            EntityPlayer target = findPlayer(args[1]);
            if (target == null) { msg(sender, "Jogador não encontrado."); return; }
            EvolutionUnlockService.Result result = EvolutionUnlockService.check(target, args[2]);
            msg(sender, (result.isAllowed() ? "Verificação: " : "Ainda não pode desbloquear: ")
                    + result.getMessage());
            return;
        }
        if ("masteryinfo".equals(sub)) {
            msg(sender, "Domínio automático: 0,02 por segundo durante forma mapeada e desbloqueada.");
            msg(sender, "Fonte de confirmação: adaptador composto (Additions primeiro; DBC nativo como alternativa).");
            msg(sender, "Limite por chamada: 0.25; somente servidor; somente formas mapeadas e já desbloqueadas contam.");
            return;
        }
        if ("progress".equals(sub)) {
            EntityPlayer target = args.length >= 2 ? findPlayer(args[1]) :
                    (sender instanceof EntityPlayer ? (EntityPlayer)sender : null);
            if (target == null) {
                msg(sender, "Jogador não encontrado. Use /dragonascension progress <jogador>.");
                return;
            }
            PlayerEvolutionData data = PlayerDataEvents.get(target);
            msg(sender, "Progresso de " + target.getCommandSenderName() + ":");
            for (EvolutionDefinition d : EvolutionRegistry.byRace(data.getRaceKey())) {
                double value = data.getMastery(d.getId());
                msg(sender, d.getDisplayName() + ": " + value + "/100 (" +
                        PlayerEvolutionData.getMasteryTier(value) + ")" +
                        (data.isUnlocked(d.getId()) ? " | desbloqueada" : " | bloqueada"));
            }
            return;
        }
        if ("status".equals(sub)) {
            EntityPlayer target = args.length >= 2 ? findPlayer(args[1]) :
                    (sender instanceof EntityPlayer ? (EntityPlayer)sender : null);
            if (target == null) { msg(sender, "Jogador não encontrado. Use /dragonascension status <jogador>."); return; }
            PlayerEvolutionData data = PlayerDataEvents.get(target);
            msg(sender, "Jogador: " + target.getCommandSenderName() + " | raça interna: " +
                    (data.getRaceKey().length() == 0 ? "não definida" : data.getRaceKey()));
            for (EvolutionDefinition d : EvolutionRegistry.all()) {
                msg(sender, d.getId() + " | domínio " + data.getMastery(d.getId()) +
                        " | " + (data.isUnlocked(d.getId()) ? "desbloqueada" : "bloqueada"));
            }
            return;
        }
        if ("setrace".equals(sub) && args.length == 3) {
            EntityPlayer target = findPlayer(args[1]);
            if (target == null) { msg(sender, "Jogador não encontrado."); return; }
            String race = args[2].toLowerCase(Locale.ROOT);
            if (!"saiyan".equals(race) && !"half_saiyan".equals(race) &&
                !"arcosian".equals(race) && !"namekian".equals(race) &&
                !"human".equals(race) && !"majin".equals(race)) {
                msg(sender, "Raças internas: saiyan, half_saiyan, arcosian, namekian, human, majin."); return;
            }
            PlayerEvolutionData data = PlayerDataEvents.get(target);
            data.setRaceKey(race);
            PlayerDataEvents.save(target, data);
            msg(sender, "Raça interna de " + target.getCommandSenderName() + " definida como " + race + ".");
            return;
        }
        if (("mastery".equals(sub) || "training".equals(sub) ||
             "challenge".equals(sub) || "unlock".equals(sub)) && args.length >= 3) {
            EntityPlayer target = findPlayer(args[1]);
            if (target == null) { msg(sender, "Jogador não encontrado."); return; }
            EvolutionDefinition def = EvolutionRegistry.get(args[2]);
            if (def == null) { msg(sender, "Evolução desconhecida: " + args[2]); return; }
            PlayerEvolutionData data = PlayerDataEvents.get(target);
            if ("mastery".equals(sub) && args.length == 4) {
                try {
                    data.setMastery(def.getId(), parseDouble(args[3]));
                    PlayerDataEvents.save(target, data);
                    msg(sender, "Domínio atualizado.");
                } catch (NumberFormatException ex) { msg(sender, "Valor inválido."); }
                return;
            }
            if ("training".equals(sub)) {
                data.completeTraining(def.getId());
                PlayerDataEvents.save(target, data);
                msg(sender, "Treinamento registrado.");
                return;
            }
            if ("challenge".equals(sub)) {
                data.completeChallenge(def.getId());
                PlayerDataEvents.save(target, data);
                msg(sender, "Desafio registrado.");
                return;
            }
            if ("unlock".equals(sub)) {
                EvolutionUnlockService.Result result = EvolutionUnlockService.unlock(target, def.getId());
                msg(sender, result.getMessage());
                return;
            }
        }
        help(sender);
    }

    private EntityPlayer findPlayer(String name) {
        return MinecraftServer.getServer().getConfigurationManager().func_152612_a(name);
    }

    private static double parseDouble(String value) {
        double result = Double.parseDouble(value);
        if (Double.isNaN(result) || Double.isInfinite(result)) throw new NumberFormatException();
        return result;
    }

    private static void msg(ICommandSender sender, String text) {
        sender.addChatMessage(new ChatComponentText("§6[Dragon Ascension] §f" + text));
    }

    private static void help(ICommandSender sender) {
        msg(sender, "/dragonascension list");
        msg(sender, "/dragonascension tree <raça>");
        msg(sender, "/dragonascension progress <jogador>");
        msg(sender, "/dragonascension check <jogador> <evolução>");
        msg(sender, "/dragonascension masteryinfo");
        msg(sender, "/dragonascension transformation <jogador>");
        msg(sender, "/dragonascension info <id-evolução>");
        msg(sender, "/dragonascension audit");
        msg(sender, "/dragonascension compat");
        msg(sender, "/dragonascension status <jogador>");
        msg(sender, "/dragonascension context <jogador>");
        msg(sender, "/dragonascension setrace <jogador> <raça>");
        msg(sender, "/dragonascension mastery <jogador> <evolução> <0-100>");
        msg(sender, "/dragonascension training|challenge <jogador> <evolução>");
        msg(sender, "/dragonascension unlock <jogador> <evolução>");
    }
}
