package com.dragonascension.compat;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Locale;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Reflection-based bridge for the verified DBC Additions 1.8.10 API.
 * Reflection metadata is cached after the first successful API probe so the
 * server does not repeat class/method lookup on every transformation tick.
 * No Additions/JRMCore types are linked at compile time.
 */
public final class DbcAdditionsTransformationAdapter implements ITransformationAdapter {
    private static final String PLAYER_CLASS =
            "com.ximen.dbcadditions.data.DBCAPlayer";
    private static final String FORMS_CLASS =
            "com.ximen.dbcadditions.data.forms.DBCAForms";
    private static final String FORM_CLASS =
            "com.ximen.dbcadditions.data.forms.DBCAForm";
    private static final String JRM_CLASS = "JinRyuu.JRMCore.JRMCoreH";

    private volatile Api api;

    private static final class Api {
        final Method getPlayer;
        final Field activeForm;
        final Method getForm;
        final Method getFormName;
        final Method getRace;
        final Method isHalfSaiyan;
        final Method isNamekian;
        final Method isArcosian;

        Api(ClassLoader loader) throws Exception {
            Class<?> playerClass = Class.forName(PLAYER_CLASS, false, loader);
            Class<?> formsClass = Class.forName(FORMS_CLASS, false, loader);
            Class<?> formClass = Class.forName(FORM_CLASS, false, loader);
            Class<?> jrmClass = Class.forName(JRM_CLASS, false, loader);

            getPlayer = playerClass.getMethod("get", EntityPlayer.class);
            activeForm = playerClass.getField("DBAForm");
            getRace = playerClass.getMethod("getRace");
            getForm = formsClass.getMethod("getForm", Integer.TYPE);
            getFormName = formClass.getMethod("getName");
            isHalfSaiyan = jrmClass.getMethod("isRaceHalfSaiyan", Integer.TYPE);
            isNamekian = jrmClass.getMethod("isRaceNamekian", Integer.TYPE);
            isArcosian = jrmClass.getMethod("isRaceArcosian", Integer.TYPE);
        }
    }

    public String getId() {
        return "dbcadditions-1.8.10";
    }

    public boolean isAvailable() {
        return getApi() != null;
    }

    private Api getApi() {
        Api cached = api;
        if (cached != null) return cached;
        synchronized (this) {
            cached = api;
            if (cached != null) return cached;
            try {
                cached = new Api(getClass().getClassLoader());
                api = cached;
                return cached;
            } catch (Exception ex) {
                return null;
            } catch (LinkageError err) {
                return null;
            }
        }
    }

    public TransformationReadResult readTransformation(EntityPlayer player) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote) return TransformationReadResult.unknown();
        Api bridge = getApi();
        if (bridge == null) return TransformationReadResult.unknown();

        try {
            Object additionsPlayer = bridge.getPlayer.invoke(null, player);
            if (additionsPlayer == null) return TransformationReadResult.unknown();

            int activeFormId = bridge.activeForm.getInt(additionsPlayer);
            if (activeFormId <= 0) return TransformationReadResult.inactive();

            Object form = bridge.getForm.invoke(null, Integer.valueOf(activeFormId));
            if (form == null) return TransformationReadResult.unknown();

            String formName = (String) bridge.getFormName.invoke(form);
            if (formName == null) return TransformationReadResult.unknown();
            formName = formName.trim().toLowerCase(Locale.ROOT);

            byte race = ((Number) bridge.getRace.invoke(additionsPlayer)).byteValue();

            if ("beast".equals(formName) && isRace(bridge.isHalfSaiyan, race)) {
                return TransformationReadResult.active("half_saiyan.beast");
            }
            if ("potential_unlocked".equals(formName) && isRace(bridge.isNamekian, race)) {
                return TransformationReadResult.active("namekian.potential");
            }
            if ("orange".equals(formName) && isRace(bridge.isNamekian, race)) {
                return TransformationReadResult.active("namekian.orange");
            }
            if (!isRace(bridge.isArcosian, race)) return TransformationReadResult.unknown();

            if ("imperfect".equals(formName)) return TransformationReadResult.active("arcosian.second_form");
            if ("semi_perfect".equals(formName)) return TransformationReadResult.active("arcosian.third_form");
            if ("perfect".equals(formName)) return TransformationReadResult.active("arcosian.final_form");
            if ("full_power".equals(formName) || "super_perfect".equals(formName)) {
                return TransformationReadResult.active("arcosian.powered_final");
            }
            if ("golden_perfect".equals(formName)) return TransformationReadResult.active("arcosian.golden");
            if ("black".equals(formName)) return TransformationReadResult.active("arcosian.black");
            return TransformationReadResult.unknown();
        } catch (Exception ex) {
            return TransformationReadResult.unknown();
        } catch (LinkageError err) {
            return TransformationReadResult.unknown();
        }
    }

    private boolean isRace(Method method, byte race) throws Exception {
        Object result = method.invoke(null, Integer.valueOf((int) race));
        return Boolean.TRUE.equals(result);
    }
}
