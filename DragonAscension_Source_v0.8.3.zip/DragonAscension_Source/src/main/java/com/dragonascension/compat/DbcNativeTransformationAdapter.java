package com.dragonascension.compat;

import java.lang.reflect.Method;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Experimental native DBC bridge using reflective JRMCore lookups.
 * Runtime compatibility and returned state names must be confirmed in-game.
 * Unsupported or unknown states are ignored rather than guessed.
 */
public final class DbcNativeTransformationAdapter implements ITransformationAdapter {
    private static final String JRM_CLASS = "JinRyuu.JRMCore.JRMCoreH";
    private volatile Api api;

    private static final class Api {
        final Method getByte;
        final Method getTransformationName;

        Api(ClassLoader loader) throws Exception {
            Class<?> jrm = Class.forName(JRM_CLASS, false, loader);
            getByte = jrm.getMethod("getByte", EntityPlayer.class, String.class);
            getTransformationName = jrm.getMethod("getTransformationName",
                    Integer.TYPE, Integer.TYPE, Boolean.TYPE, Boolean.TYPE,
                    Boolean.TYPE, Boolean.TYPE);
        }
    }

    private Api getApi() {
        Api current = api;
        if (current != null) return current;
        synchronized (this) {
            current = api;
            if (current != null) return current;
            try {
                current = new Api(getClass().getClassLoader());
                api = current;
                return current;
            } catch (Exception ex) {
                return null;
            } catch (LinkageError err) {
                return null;
            }
        }
    }

    public String getId() {
        return "dragonblockc-native-jrmcore-1.3.51";
    }

    public boolean isAvailable() {
        return getApi() != null;
    }

    public TransformationReadResult readTransformation(EntityPlayer player) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote) return TransformationReadResult.unknown();
        Api bridge = getApi();
        if (bridge == null) return TransformationReadResult.unknown();

        try {
            int race = ((Number) bridge.getByte.invoke(null, player, "jrmcRace")).intValue();
            int state = ((Number) bridge.getByte.invoke(null, player, "jrmcState")).intValue();
            if (state < 0) state += 256;

            Object value = bridge.getTransformationName.invoke(null,
                    Integer.valueOf(race), Integer.valueOf(state),
                    Boolean.FALSE, Boolean.FALSE, Boolean.FALSE, Boolean.FALSE);
            if (!(value instanceof String)) return TransformationReadResult.unknown();

            String name = (String) value;
            if (race == 1) {
                if ("Super".equals(name)) return TransformationReadResult.active("saiyan.ssj");
                if ("SuperFP".equals(name)) return TransformationReadResult.active("saiyan.ssj_full_power");
                if ("Super2".equals(name)) return TransformationReadResult.active("saiyan.ssj2");
                if ("Super3".equals(name)) return TransformationReadResult.active("saiyan.ssj3");
            } else if (race == 2) {
                if ("Super".equals(name)) return TransformationReadResult.active("half_saiyan.ssj");
                if ("Super2".equals(name)) return TransformationReadResult.active("half_saiyan.ssj2");
            }
            return TransformationReadResult.unknown();
        } catch (Exception ex) {
            return TransformationReadResult.unknown();
        } catch (LinkageError err) {
            return TransformationReadResult.unknown();
        }
    }
}
