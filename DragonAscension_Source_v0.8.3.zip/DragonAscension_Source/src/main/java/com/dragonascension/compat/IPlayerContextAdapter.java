package com.dragonascension.compat;

import net.minecraft.entity.player.EntityPlayer;

/** Implemented by a version-specific adapter after its target API is verified. */
public interface IPlayerContextAdapter {
    String getId();
    boolean isAvailable();
    PlayerContext read(EntityPlayer player);
}
