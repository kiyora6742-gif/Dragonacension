package com.dragonascension.compat;

import net.minecraft.entity.player.EntityPlayer;

/** Combines optional adapters without confusing an unreadable state with inactivity. */
public final class CompositeTransformationAdapter implements ITransformationAdapter {
    private final ITransformationAdapter primary;
    private final ITransformationAdapter fallback;

    public CompositeTransformationAdapter(ITransformationAdapter primary,
                                          ITransformationAdapter fallback) {
        if (primary == null && fallback == null) throw new IllegalArgumentException("At least one adapter is required");
        this.primary = primary;
        this.fallback = fallback;
    }

    public String getId() {
        if (primary != null && fallback != null) return primary.getId() + "+" + fallback.getId();
        return primary != null ? primary.getId() : fallback.getId();
    }

    public boolean isAvailable() { return available(primary) || available(fallback); }

    public TransformationReadResult readTransformation(EntityPlayer player) {
        TransformationReadResult first = read(primary, player);
        if (first.getStatus() == TransformationReadResult.Status.ACTIVE) return first;
        TransformationReadResult second = read(fallback, player);
        if (second.getStatus() == TransformationReadResult.Status.ACTIVE) return second;
        if (first.getStatus() == TransformationReadResult.Status.INACTIVE
                && second.getStatus() == TransformationReadResult.Status.INACTIVE) {
            return TransformationReadResult.inactive();
        }
        if (primary == null) return second;
        if (fallback == null) return first;
        return TransformationReadResult.unknown();
    }

    private boolean available(ITransformationAdapter adapter) {
        if (adapter == null) return false;
        try { return adapter.isAvailable(); }
        catch (RuntimeException ex) { return false; }
        catch (LinkageError err) { return false; }
    }

    private TransformationReadResult read(ITransformationAdapter adapter, EntityPlayer player) {
        if (adapter == null || !available(adapter)) return TransformationReadResult.unknown();
        try {
            TransformationReadResult result = adapter.readTransformation(player);
            return result == null ? TransformationReadResult.unknown() : result;
        } catch (RuntimeException ex) { return TransformationReadResult.unknown(); }
        catch (LinkageError err) { return TransformationReadResult.unknown(); }
    }
}
