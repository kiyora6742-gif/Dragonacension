package com.dragonascension.compat;

import net.minecraft.entity.player.EntityPlayer;

/**
 * Optional server-side bridge for a verified energy API.
 * Implementations must atomically verify and subtract the requested amount.
 * Return false when the player has insufficient energy or the API is unavailable.
 */
public interface IPlayerEnergyAdapter {
    String getId();
    boolean isAvailable();
    boolean consume(EntityPlayer player, double amount);
}
