package com.dragonascension.compat;

import java.lang.reflect.Method;
import net.minecraft.entity.player.EntityPlayer;

/**
 * JRMCore 1.3.51 context adapter.
 * Uses per-player APIs; does not read JRMCoreH's mutable client/global snapshots.
 */
public final class JrmCorePlayerContextAdapter implements IPlayerContextAdapter {
    private static final String JRM_CLASS = "JinRyuu.JRMCore.JRMCoreH";

    public String getId() {
        return "jrmcore-1.3.51";
    }

    public boolean isAvailable() {
        try {
            Class<?> jrm = Class.forName(JRM_CLASS, false, getClass().getClassLoader());
            jrm.getMethod("getByte", EntityPlayer.class, String.class);
            jrm.getMethod("getInt", EntityPlayer.class, String.class);
            jrm.getMethod("PlyrAttrbts", EntityPlayer.class);
            jrm.getMethod("getPlayerLevel", int[].class);
            jrm.getMethod("isRaceFullSaiyan", Integer.TYPE);
            jrm.getMethod("isRaceHalfSaiyan", Integer.TYPE);
            jrm.getMethod("isRaceHuman", Integer.TYPE);
            jrm.getMethod("isRaceNamekian", Integer.TYPE);
            jrm.getMethod("isRaceArcosian", Integer.TYPE);
            jrm.getMethod("isRaceMajin", Integer.TYPE);
            return true;
        } catch (Exception ex) {
            return false;
        } catch (LinkageError err) {
            return false;
        }
    }

    public PlayerContext read(EntityPlayer player) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote) return null;
        try {
            Class<?> jrm = Class.forName(JRM_CLASS, false, getClass().getClassLoader());
            Method getByte = jrm.getMethod("getByte", EntityPlayer.class, String.class);
            Method getInt = jrm.getMethod("getInt", EntityPlayer.class, String.class);
            Method attributesMethod = jrm.getMethod("PlyrAttrbts", EntityPlayer.class);
            Method levelMethod = jrm.getMethod("getPlayerLevel", int[].class);

            int race = ((Number) getByte.invoke(null, player, "jrmcRace")).intValue();
            String raceKey = resolveRace(jrm, race);
            if (raceKey == null) return null;

            int[] attributes = (int[]) attributesMethod.invoke(null, player);
            Integer level = null;
            if (attributes != null && attributes.length >= 6) {
                level = Integer.valueOf(((Number) levelMethod.invoke(null,
                        new Object[] { attributes })).intValue());
            }

            Double energy = Double.valueOf(((Number) getInt.invoke(
                    null, player, "jrmcEnrgy")).intValue());
            return new PlayerContext(raceKey, level, energy, getId());
        } catch (Exception ex) {
            return null;
        } catch (LinkageError err) {
            return null;
        }
    }

    private String resolveRace(Class<?> jrm, int race) throws Exception {
        if (isRace(jrm, "isRaceFullSaiyan", race)) return "saiyan";
        if (isRace(jrm, "isRaceHalfSaiyan", race)) return "half_saiyan";
        if (isRace(jrm, "isRaceHuman", race)) return "human";
        if (isRace(jrm, "isRaceNamekian", race)) return "namekian";
        if (isRace(jrm, "isRaceArcosian", race)) return "arcosian";
        if (isRace(jrm, "isRaceMajin", race)) return "majin";
        return null;
    }

    private boolean isRace(Class<?> jrm, String methodName, int race) throws Exception {
        Object result = jrm.getMethod(methodName, Integer.TYPE)
                .invoke(null, Integer.valueOf(race));
        return Boolean.TRUE.equals(result);
    }
}
