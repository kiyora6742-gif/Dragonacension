package com.dragonascension.compat;

/** Immutable, sanitized snapshot supplied by an optional integration adapter. */
public final class PlayerContext {
    private final String raceKey;
    private final Integer level;
    private final Double energy;
    private final String provider;

    public PlayerContext(String raceKey, Integer level, Double energy, String provider) {
        String normalizedRace = raceKey == null ? null : raceKey.trim().toLowerCase(java.util.Locale.ROOT);
        this.raceKey = normalizedRace == null || normalizedRace.length() == 0 ? null : normalizedRace;
        this.level = level != null && level.intValue() >= 0 ? level : null;
        this.energy = energy != null && !Double.isNaN(energy.doubleValue())
                && !Double.isInfinite(energy.doubleValue()) && energy.doubleValue() >= 0.0D
                ? energy : null;
        String normalizedProvider = provider == null ? "" : provider.trim();
        this.provider = normalizedProvider.length() == 0 ? "unknown" : normalizedProvider;
    }

    public String getRaceKey() { return raceKey; }
    public Integer getLevel() { return level; }
    public Double getEnergy() { return energy; }
    public String getProvider() { return provider; }
    public boolean hasRace() { return raceKey != null; }
    public boolean hasLevel() { return level != null; }
    public boolean hasEnergy() { return energy != null; }
}
