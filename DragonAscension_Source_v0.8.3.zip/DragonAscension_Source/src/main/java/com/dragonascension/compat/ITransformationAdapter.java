package com.dragonascension.compat;

import net.minecraft.entity.player.EntityPlayer;

/** Optional bridge implemented only after a target mod's API is verified. */
public interface ITransformationAdapter {
    String getId();
    boolean isAvailable();
    TransformationReadResult readTransformation(EntityPlayer player);
}
