package com.dragonascension.compat;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Reflective JRMCore 1.3.51 energy bridge.
 * It is enabled only when the exact getInt/setInt signatures exist.
 * Every write is read back; failed verification attempts a rollback.
 * This bridge remains experimental until checked against the exact JRMCore JAR.
 */
public final class JrmCoreEnergyAdapter implements IPlayerEnergyAdapter {
    private static final String JRM_CLASS = "JinRyuu.JRMCore.JRMCoreH";
    private static final String ENERGY_KEY = "jrmcEnrgy";

    private static final class Api {
        final Method getInt;
        final Method setInt;
        Api(Class<?> type) throws Exception {
            getInt = type.getMethod("getInt", EntityPlayer.class, String.class);
            setInt = type.getMethod("setInt", Integer.TYPE, EntityPlayer.class, String.class);
            if (!Modifier.isStatic(getInt.getModifiers())
                    || !Modifier.isStatic(setInt.getModifiers())
                    || !(getInt.getReturnType() == Integer.TYPE
                         || Number.class.isAssignableFrom(getInt.getReturnType()))) {
                throw new NoSuchMethodException("JRMCore energy methods have incompatible modifiers/return type");
            }
        }
    }

    private volatile Api api;
    private volatile boolean apiResolved;

    public String getId() { return "jrmcore-reflective-energy-experimental"; }

    public boolean isAvailable() { return getApi() != null; }

    private Api getApi() {
        Api cached = api;
        if (apiResolved) return cached;
        synchronized (this) {
            cached = api;
            if (apiResolved) return cached;
            try {
                Class<?> type = Class.forName(JRM_CLASS, false, getClass().getClassLoader());
                cached = new Api(type);
                api = cached;
                apiResolved = true;
                return cached;
            } catch (Exception ex) {
                apiResolved = true;
                return null;
            } catch (LinkageError err) {
                apiResolved = true;
                return null;
            }
        }
    }

    public boolean consume(EntityPlayer player, double amount) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote
                || amount <= 0.0D || Double.isNaN(amount) || Double.isInfinite(amount)) return false;
        Api bridge = getApi();
        if (bridge == null) return false;
        int cost = (int) Math.ceil(amount);
        if (cost <= 0) return false;

        int before;
        try {
            before = ((Number) bridge.getInt.invoke(null, player, ENERGY_KEY)).intValue();
        } catch (Exception ex) {
            return false;
        } catch (LinkageError err) {
            return false;
        }
        if (before < cost) return false;
        final int expected = before - cost;
        boolean writeAttempted = false;
        try {
            writeAttempted = true;
            bridge.setInt.invoke(null, Integer.valueOf(expected), player, ENERGY_KEY);
            int after = ((Number) bridge.getInt.invoke(null, player, ENERGY_KEY)).intValue();
            if (after == expected) return true;
        } catch (Exception ex) {
            // A setter can mutate the value and then throw (or read-back can fail).
            // Try to restore the pre-charge balance before reporting failure.
        } catch (LinkageError err) {
            // Optional integrations must fail closed even if their classes unload/break.
        }

        if (writeAttempted) {
            try {
                bridge.setInt.invoke(null, Integer.valueOf(before), player, ENERGY_KEY);
                int restored = ((Number) bridge.getInt.invoke(null, player, ENERGY_KEY)).intValue();
                if (restored != before) {
                    // The rollback could not be verified; the integration remains failed closed.
                    return false;
                }
            } catch (Exception rollbackFailure) {
                return false;
            } catch (LinkageError rollbackFailure) {
                return false;
            }
        }
        return false;
    }
}
