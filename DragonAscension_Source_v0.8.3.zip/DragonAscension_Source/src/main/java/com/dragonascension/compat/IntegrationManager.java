package com.dragonascension.compat;

import cpw.mods.fml.common.Loader;
import com.dragonascension.core.EvolutionDefinition;
import com.dragonascension.core.EvolutionRegistry;
import net.minecraft.entity.player.EntityPlayer;

/** Central point for optional integrations. No DBC/JRMCore classes are linked here. */
public final class IntegrationManager {
    private static volatile IPlayerContextAdapter playerContextAdapter;
    private static volatile ITransformationAdapter transformationAdapter;
    private static volatile IPlayerEnergyAdapter playerEnergyAdapter;

    private IntegrationManager() { }

    public static synchronized void registerPlayerContextAdapter(IPlayerContextAdapter adapter) {
        playerContextAdapter = adapter;
    }

    public static boolean isPlayerContextAdapterRegistered() {
        return playerContextAdapter != null;
    }

    public static boolean hasPlayerContextAdapter() {
        IPlayerContextAdapter adapter = playerContextAdapter;
        if (adapter == null) return false;
        try { return adapter.isAvailable(); }
        catch (RuntimeException ex) { return false; }
        catch (LinkageError err) { return false; }
    }

    public static PlayerContext readPlayerContext(EntityPlayer player) {
        IPlayerContextAdapter adapter = playerContextAdapter;
        if (player == null || adapter == null) return null;
        try {
            if (!adapter.isAvailable()) return null;
            return adapter.read(player);
        } catch (RuntimeException ex) {
            return null;
        } catch (LinkageError err) {
            // Optional integrations must never crash the base mod when their API is absent.
            return null;
        }
    }

    public static String getPlayerContextProviderId() {
        IPlayerContextAdapter adapter = playerContextAdapter;
        if (adapter == null || !hasPlayerContextAdapter()) return null;
        try { return adapter.getId(); }
        catch (RuntimeException ex) { return null; }
        catch (LinkageError err) { return null; }
    }


    public static synchronized void registerPlayerEnergyAdapter(IPlayerEnergyAdapter adapter) {
        playerEnergyAdapter = adapter;
    }

    public static boolean hasPlayerEnergyAdapter() {
        IPlayerEnergyAdapter adapter = playerEnergyAdapter;
        if (adapter == null) return false;
        try { return adapter.isAvailable(); }
        catch (RuntimeException ex) { return false; }
        catch (LinkageError err) { return false; }
    }

    /** Applies energy cost only through an explicitly registered, verified adapter. */
    public static boolean consumePlayerEnergy(EntityPlayer player, double amount) {
        IPlayerEnergyAdapter adapter = playerEnergyAdapter;
        if (player == null || adapter == null || amount <= 0.0D
                || Double.isNaN(amount) || Double.isInfinite(amount)) return false;
        try {
            return adapter.isAvailable() && adapter.consume(player, amount);
        } catch (RuntimeException ex) {
            return false;
        } catch (LinkageError err) {
            return false;
        }
    }

    public static String getPlayerEnergyProviderId() {
        IPlayerEnergyAdapter adapter = playerEnergyAdapter;
        if (adapter == null || !hasPlayerEnergyAdapter()) return null;
        try { return adapter.getId(); }
        catch (RuntimeException ex) { return null; }
        catch (LinkageError err) { return null; }
    }

    public static synchronized void registerTransformationAdapter(ITransformationAdapter adapter) {
        transformationAdapter = adapter;
    }

    public static boolean isTransformationAdapterRegistered() {
        return transformationAdapter != null;
    }

    public static boolean hasTransformationAdapter() {
        ITransformationAdapter adapter = transformationAdapter;
        if (adapter == null) return false;
        try { return adapter.isAvailable(); }
        catch (RuntimeException ex) { return false; }
        catch (LinkageError err) { return false; }
    }

    /**
     * Returns a tri-state result. UNKNOWN is deliberately distinct from INACTIVE:
     * a reflection/API failure must not terminate a previously confirmed session.
     */
    public static TransformationReadResult readTransformation(EntityPlayer player) {
        ITransformationAdapter adapter = transformationAdapter;
        if (player == null || adapter == null) return TransformationReadResult.unknown();
        try {
            if (!adapter.isAvailable()) return TransformationReadResult.unknown();
            TransformationReadResult result = adapter.readTransformation(player);
            if (result == null) return TransformationReadResult.unknown();
            if (result.getStatus() != TransformationReadResult.Status.ACTIVE) return result;
            EvolutionDefinition definition = EvolutionRegistry.get(result.getEvolutionId());
            return definition == null ? TransformationReadResult.unknown()
                    : TransformationReadResult.active(definition.getId());
        } catch (RuntimeException ex) {
            return TransformationReadResult.unknown();
        } catch (LinkageError err) {
            return TransformationReadResult.unknown();
        }
    }

    public static String getTransformationProviderId() {
        ITransformationAdapter adapter = transformationAdapter;
        if (adapter == null || !hasTransformationAdapter()) return null;
        try { return adapter.getId(); }
        catch (RuntimeException ex) { return null; }
        catch (LinkageError err) { return null; }
    }

    /** Mod IDs are candidate identifiers; presence alone does not prove API compatibility. */
    public static boolean isDragonBlockCPresent() {
        return loaded("jinryuudragonblockc") || loaded("DragonBlockC") || loaded("dragonblockc");
    }

    public static boolean isJRMCorePresent() {
        return loaded("jinryuujrmcore") || loaded("JRMCore") || loaded("jrmcore");
    }

    public static boolean isAdditionsPresent() {
        return loaded("dbcadditions") || loaded("DBCAdditions");
    }


    /**
     * Probes known API entry-point classes without initializing or linking them.
     * A positive result proves class visibility only, not method compatibility.
     */
    public static boolean isDragonBlockCApiClassVisible() {
        return classVisible("JinRyuu.DragonBC.common.DBCKiTech");
    }

    public static boolean isJRMCoreApiClassVisible() {
        return classVisible("JinRyuu.JRMCore.JRMCoreH");
    }

    public static boolean isAdditionsApiClassVisible() {
        return classVisible("com.ximen.dbcadditions.data.forms.FormItem")
                && classVisible("com.ximen.dbcadditions.data.forms.DBCAPlayer");
    }

    private static boolean classVisible(String className) {
        try {
            ClassLoader loader = IntegrationManager.class.getClassLoader();
            Class.forName(className, false, loader);
            return true;
        } catch (ClassNotFoundException ex) {
            return false;
        } catch (LinkageError err) {
            return false;
        } catch (SecurityException ex) {
            return false;
        }
    }

    private static boolean loaded(String modId) {
        try { return Loader.isModLoaded(modId); }
        catch (RuntimeException ex) { return false; }
        catch (LinkageError err) { return false; }
    }
}
