package com.dragonascension.compat;

/**
 * Three-state result for optional transformation integrations.
 * UNKNOWN means the API could not safely determine the state; it must never
 * be treated as an instruction to end a previously confirmed session.
 */
public final class TransformationReadResult {
    public enum Status { UNKNOWN, INACTIVE, ACTIVE }

    private static final TransformationReadResult UNKNOWN =
            new TransformationReadResult(Status.UNKNOWN, null);
    private static final TransformationReadResult INACTIVE =
            new TransformationReadResult(Status.INACTIVE, null);

    private final Status status;
    private final String evolutionId;

    private TransformationReadResult(Status status, String evolutionId) {
        this.status = status;
        this.evolutionId = evolutionId;
    }

    public static TransformationReadResult unknown() { return UNKNOWN; }
    public static TransformationReadResult inactive() { return INACTIVE; }
    public static TransformationReadResult active(String evolutionId) {
        if (evolutionId == null || evolutionId.trim().length() == 0) return UNKNOWN;
        return new TransformationReadResult(Status.ACTIVE, evolutionId.trim());
    }

    public Status getStatus() { return status; }
    public String getEvolutionId() { return evolutionId; }
}
