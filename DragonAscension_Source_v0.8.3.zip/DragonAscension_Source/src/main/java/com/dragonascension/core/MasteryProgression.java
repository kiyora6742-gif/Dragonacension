package com.dragonascension.core;

import com.dragonascension.event.PlayerDataEvents;
import net.minecraft.entity.player.EntityPlayer;

/**
 * API interna para registrar uso real de uma transformação.
 *
 * Um adaptador de DBC/DBC Additions deverá chamar recordTransformationUse
 * somente após confirmar que o jogador está naquela forma. Não há ganho
 * automático enquanto essa confirmação não existir.
 */
public final class MasteryProgression {
    private static final double MAX_AWARD_PER_CALL = 0.25D;

    private MasteryProgression() { }

    /**
     * Registra progresso de domínio após uso confirmado de uma forma.
     *
     * @return true se o progresso foi aplicado e salvo.
     */
    public static boolean recordTransformationUse(EntityPlayer player,
            String evolutionId, double amount) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote) return false;
        if (evolutionId == null || EvolutionRegistry.get(evolutionId) == null) return false;
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0.0D) return false;
        if (amount > MAX_AWARD_PER_CALL) amount = MAX_AWARD_PER_CALL;

        PlayerEvolutionData data = PlayerDataEvents.get(player);
        if (!data.isUnlocked(evolutionId)) return false;

        double before = data.getMastery(evolutionId);
        if (before >= 100.0D) return false;
        data.addMastery(evolutionId, amount);
        if (data.getMastery(evolutionId) <= before) return false;
        PlayerDataEvents.save(player, data);
        return true;
    }

    public static double getMaxAwardPerCall() {
        return MAX_AWARD_PER_CALL;
    }
}
