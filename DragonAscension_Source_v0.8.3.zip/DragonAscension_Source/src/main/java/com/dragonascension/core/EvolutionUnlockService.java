package com.dragonascension.core;

import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.compat.PlayerContext;
import com.dragonascension.event.PlayerDataEvents;
import net.minecraft.entity.player.EntityPlayer;

/** Único caminho para pré-validar e efetivar desbloqueios. */
public final class EvolutionUnlockService {
    private EvolutionUnlockService() { }

    public static Result check(EntityPlayer player, String evolutionId) {
        return evaluate(player, evolutionId, false);
    }

    public static Result unlock(EntityPlayer player, String evolutionId) {
        return evaluate(player, evolutionId, true);
    }

    private static Result evaluate(EntityPlayer player, String evolutionId, boolean commit) {
        if (player == null) return new Result(false, false, "Jogador indisponível.");
        if (player.worldObj == null || player.worldObj.isRemote)
            return new Result(false, false, "Desbloqueios só podem ser processados no servidor.");
        EvolutionDefinition definition = EvolutionRegistry.get(evolutionId);
        if (definition == null) return new Result(false, false, "Evolução desconhecida.");
        PlayerEvolutionData data = PlayerDataEvents.get(player);
        String raceKey = getVerifiedRaceKey(player, data);
        if (raceKey == null)
            return new Result(false, false,
                    "Raça não verificável: integração indisponível ou dados ausentes.");
        if (!definition.getRaceKey().equals(raceKey))
            return new Result(false, false, "Raça incompatível.");
        if (data.isUnlocked(evolutionId))
            return new Result(true, false, "Essa evolução já está desbloqueada.");

        PlayerContext context = IntegrationManager.readPlayerContext(player);
        Integer level = context == null ? null : context.getLevel();
        String reason = EvolutionValidator.validate(definition, raceKey, level, data);
        if (reason != null) return new Result(false, false, reason);

        if (commit) {
            data.unlock(evolutionId);
            PlayerDataEvents.save(player, data);
            return new Result(true, true, "Evolução desbloqueada.");
        }
        return new Result(true, false, "Requisitos atendidos.");
    }


    /**
     * Returns the current race only when it can be trusted. If an adapter was
     * registered but is unavailable, saved data is not used as a silent fallback.
     */
    public static String getVerifiedRaceKey(EntityPlayer player, PlayerEvolutionData data) {
        if (player == null || data == null || player.worldObj == null || player.worldObj.isRemote)
            return null;
        if (IntegrationManager.isPlayerContextAdapterRegistered()) {
            if (!IntegrationManager.hasPlayerContextAdapter()) return null;
            PlayerContext context = IntegrationManager.readPlayerContext(player);
            return context != null && context.hasRace() ? context.getRaceKey() : null;
        }
        String savedRace = data.getRaceKey();
        return savedRace == null || savedRace.length() == 0 ? null : savedRace;
    }

    public static final class Result {
        private final boolean allowed;
        private final boolean changed;
        private final String message;

        private Result(boolean allowed, boolean changed, String message) {
            this.allowed = allowed;
            this.changed = changed;
            this.message = message;
        }
        public boolean isAllowed() { return allowed; }
        public boolean hasChanged() { return changed; }
        public String getMessage() { return message; }
    }
}
