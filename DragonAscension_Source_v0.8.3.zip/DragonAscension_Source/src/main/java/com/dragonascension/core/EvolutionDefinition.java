package com.dragonascension.core;

public final class EvolutionDefinition {
    private final String id;
    private final String displayName;
    private final String raceKey;
    private final String parentId;
    private final int requiredLevel;
    private final double requiredMastery;
    private final boolean requiresTraining;
    private final boolean requiresChallenge;
    private final boolean enabled;

    public EvolutionDefinition(String id, String displayName, String raceKey,
            String parentId, int requiredLevel, double requiredMastery,
            boolean requiresTraining, boolean requiresChallenge, boolean enabled) {
        if (id == null || id.trim().length() == 0) throw new IllegalArgumentException("id vazio");
        if (raceKey == null || raceKey.trim().length() == 0) throw new IllegalArgumentException("raceKey vazio");
        if (requiredLevel < 0) throw new IllegalArgumentException("requiredLevel negativo");
        if (requiredMastery < 0.0D || requiredMastery > 100.0D) throw new IllegalArgumentException("mastery fora de 0..100");
        this.id = id;
        this.displayName = displayName == null ? id : displayName;
        this.raceKey = raceKey;
        this.parentId = parentId;
        this.requiredLevel = requiredLevel;
        this.requiredMastery = requiredMastery;
        this.requiresTraining = requiresTraining;
        this.requiresChallenge = requiresChallenge;
        this.enabled = enabled;
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public String getRaceKey() { return raceKey; }
    public String getParentId() { return parentId; }
    public int getRequiredLevel() { return requiredLevel; }
    public double getRequiredMastery() { return requiredMastery; }
    public boolean requiresTraining() { return requiresTraining; }
    public boolean requiresChallenge() { return requiresChallenge; }
    public boolean isEnabled() { return enabled; }
}
