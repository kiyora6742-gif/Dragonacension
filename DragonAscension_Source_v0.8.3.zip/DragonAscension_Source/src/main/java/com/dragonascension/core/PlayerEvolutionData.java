package com.dragonascension.core;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;

public final class PlayerEvolutionData {
    private final Set<String> unlocked = new HashSet<String>();
    private final Map<String, Double> mastery = new HashMap<String, Double>();
    private final Set<String> completedTraining = new HashSet<String>();
    private final Set<String> completedChallenges = new HashSet<String>();
    private String raceKey = "";
    private String activeTransformationId = "";
    private long confirmedTransformationUseEvents = 0L;

    public String getRaceKey() { return raceKey; }
    public String getActiveTransformationId() { return activeTransformationId; }
    public void setActiveTransformationId(String id) {
        activeTransformationId = id == null ? "" : id.trim();
    }
    /** Clears a session marker when the actual external form can no longer be trusted. */
    public void clearActiveTransformation() {
        activeTransformationId = "";
    }
    public long getConfirmedTransformationUseEvents() { return confirmedTransformationUseEvents; }
    public void incrementConfirmedTransformationUseEvents() {
        if (confirmedTransformationUseEvents < Long.MAX_VALUE) confirmedTransformationUseEvents++;
    }
    public void setRaceKey(String value) {
        String nextRace = value == null ? "" : value.trim().toLowerCase(java.util.Locale.ROOT);
        if (!nextRace.equals(raceKey)) {
            raceKey = nextRace;
            pruneForeignRaceProgress();
        }
    }

    /** Removes progress belonging to another race after a verified race change. */
    private void pruneForeignRaceProgress() {
        java.util.Iterator<String> unlockedIt = unlocked.iterator();
        while (unlockedIt.hasNext()) {
            EvolutionDefinition def = EvolutionRegistry.get(unlockedIt.next());
            if (def == null || !def.getRaceKey().equals(raceKey)) unlockedIt.remove();
        }
        pruneRaceSet(completedTraining);
        pruneRaceSet(completedChallenges);
        java.util.Iterator<String> masteryIt = mastery.keySet().iterator();
        while (masteryIt.hasNext()) {
            EvolutionDefinition def = EvolutionRegistry.get(masteryIt.next());
            if (def == null || !def.getRaceKey().equals(raceKey)) masteryIt.remove();
        }
        EvolutionDefinition active = EvolutionRegistry.get(activeTransformationId);
        if (active == null || !active.getRaceKey().equals(raceKey)) clearActiveTransformation();
    }

    private void pruneRaceSet(Set<String> values) {
        java.util.Iterator<String> it = values.iterator();
        while (it.hasNext()) {
            EvolutionDefinition def = EvolutionRegistry.get(it.next());
            if (def == null || !def.getRaceKey().equals(raceKey)) it.remove();
        }
    }
    public boolean isUnlocked(String id) { return id != null && unlocked.contains(id); }
    public void unlock(String id) {
        EvolutionDefinition definition = id == null ? null : EvolutionRegistry.get(id);
        if (definition != null && definition.getRaceKey().equals(raceKey)) unlocked.add(id);
    }

    public double getMastery(String id) {
        if (id == null) return 0.0D;
        Double value = mastery.get(id);
        return value == null ? 0.0D : value.doubleValue();
    }

    /** Faixas de domínio globais usadas apenas para exibição do progresso. */
    public static String getMasteryTier(double value) {
        double safe = Double.isNaN(value) || Double.isInfinite(value)
                ? 0.0D : Math.max(0.0D, Math.min(100.0D, value));
        if (safe < 20.0D) return "Iniciante";
        if (safe < 50.0D) return "Aprendiz";
        if (safe < 75.0D) return "Experiente";
        if (safe < 100.0D) return "Avançado";
        return "Máximo";
    }

    public void setMastery(String id, double value) {
        if (id == null || Double.isNaN(value) || Double.isInfinite(value)) return;
        EvolutionDefinition definition = EvolutionRegistry.get(id);
        if (definition == null || !definition.isEnabled()
                || !definition.getRaceKey().equals(raceKey)) return;
        mastery.put(id, Double.valueOf(Math.max(0.0D, Math.min(100.0D, value))));
    }

    public void addMastery(String id, double amount) {
        if (amount > 0.0D) setMastery(id, getMastery(id) + amount);
    }

    public void completeTraining(String id) {
        EvolutionDefinition definition = id == null ? null : EvolutionRegistry.get(id);
        if (definition != null && definition.getRaceKey().equals(raceKey)) completedTraining.add(id);
    }
    public void completeChallenge(String id) {
        EvolutionDefinition definition = id == null ? null : EvolutionRegistry.get(id);
        if (definition != null && definition.getRaceKey().equals(raceKey)) completedChallenges.add(id);
    }
    public boolean hasTraining(String id) { return completedTraining.contains(id); }
    public boolean hasChallenge(String id) { return completedChallenges.contains(id); }

    public void writeToNBT(NBTTagCompound root) {
        NBTTagCompound data = new NBTTagCompound();
        data.setString("RaceKey", raceKey);
        data.setString("ActiveTransformationId", activeTransformationId);
        data.setLong("ConfirmedTransformationUseEvents", confirmedTransformationUseEvents);
        writeSet(data, "Unlocked", unlocked);
        writeSet(data, "Training", completedTraining);
        writeSet(data, "Challenges", completedChallenges);
        NBTTagList list = new NBTTagList();
        for (Map.Entry<String, Double> entry : mastery.entrySet()) {
            NBTTagCompound item = new NBTTagCompound();
            item.setString("Id", entry.getKey());
            item.setDouble("Value", entry.getValue().doubleValue());
            list.appendTag(item);
        }
        data.setTag("Mastery", list);
        root.setTag("DragonAscension", data);
    }

    public void readFromNBT(NBTTagCompound root) {
        unlocked.clear(); mastery.clear(); completedTraining.clear(); completedChallenges.clear();
        raceKey = "";
        activeTransformationId = "";
        confirmedTransformationUseEvents = 0L;
        if (!root.hasKey("DragonAscension")) return;
        NBTTagCompound data = root.getCompoundTag("DragonAscension");
        setRaceKey(data.getString("RaceKey"));
        setActiveTransformationId(data.getString("ActiveTransformationId"));
        confirmedTransformationUseEvents = Math.max(0L, data.getLong("ConfirmedTransformationUseEvents"));
        readSet(data, "Unlocked", unlocked);
        readSet(data, "Training", completedTraining);
        readSet(data, "Challenges", completedChallenges);
        EvolutionDefinition activeDefinition = EvolutionRegistry.get(activeTransformationId);
        if (activeDefinition == null || !activeDefinition.isEnabled()
                || !activeDefinition.getRaceKey().equals(raceKey)
                || !unlocked.contains(activeTransformationId)) {
            clearActiveTransformation();
        }
        NBTTagList list = data.getTagList("Mastery", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound item = list.getCompoundTagAt(i);
            String id = item.getString("Id");
            EvolutionDefinition definition = EvolutionRegistry.get(id);
            if (definition != null && definition.isEnabled()
                    && definition.getRaceKey().equals(raceKey)) {
                setMastery(id, item.getDouble("Value"));
            }
        }
    }

    private static void writeSet(NBTTagCompound tag, String key, Set<String> values) {
        NBTTagList list = new NBTTagList();
        for (String value : values) list.appendTag(new NBTTagString(value));
        tag.setTag(key, list);
    }

    private void readSet(NBTTagCompound tag, String key, Set<String> target) {
        NBTTagList list = tag.getTagList(key, 8);
        for (int i = 0; i < list.tagCount(); i++) {
            String id = list.getStringTagAt(i);
            EvolutionDefinition definition = EvolutionRegistry.get(id);
            if (definition != null && definition.isEnabled()
                    && definition.getRaceKey().equals(raceKey)) target.add(id);
        }
    }
}
