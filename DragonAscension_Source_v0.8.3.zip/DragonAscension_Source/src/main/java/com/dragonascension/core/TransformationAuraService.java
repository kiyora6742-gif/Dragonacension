package com.dragonascension.core;

import java.lang.reflect.Method;
import net.minecraft.entity.player.EntityPlayer;

/** Server-side aura particles broadcast through WorldServer in Minecraft 1.7.10. */
public final class TransformationAuraService {
    private static final String[] WORLD_SERVER_PARTICLE_METHODS = {
            "func_147487_a", "spawnParticle"
    };
    private static volatile Method particleBroadcast;
    private static volatile Class<?> particleWorldClass;

    private TransformationAuraService() { }

    /**
     * Emits a small transformation aura to nearby clients. Returns false when the
     * runtime world does not expose the expected 1.7.10 WorldServer method.
     */
    public static boolean emit(EntityPlayer player, String evolutionId) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote
                || evolutionId == null || evolutionId.length() == 0) return false;
        String particle = particleFor(evolutionId);
        if (particle == null) return false;

        Method broadcast = findBroadcastMethod(player.worldObj.getClass());
        if (broadcast == null) return false;

        double angle = player.ticksExisted * 0.35D;
        double radius = 0.65D;
        double x = player.posX + Math.cos(angle) * radius;
        double z = player.posZ + Math.sin(angle) * radius;
        double y = player.posY + 0.65D + (player.ticksExisted % 7) * 0.12D;
        try {
            // One particle per sample keeps multiplayer traffic modest (4 samples/sec).
            broadcast.invoke(player.worldObj, particle, x, y, z, Integer.valueOf(1),
                    Double.valueOf(0.08D), Double.valueOf(0.12D), Double.valueOf(0.08D),
                    Double.valueOf(0.015D));
            return true;
        } catch (Exception ignored) {
            return false;
        } catch (LinkageError ignored) {
            return false;
        }
    }

    private static Method findBroadcastMethod(Class<?> worldClass) {
        if (worldClass == null) return null;
        if (particleWorldClass == worldClass) return particleBroadcast;
        synchronized (TransformationAuraService.class) {
            if (particleWorldClass == worldClass) return particleBroadcast;
            Method found = null;
            for (int i = 0; i < WORLD_SERVER_PARTICLE_METHODS.length && found == null; i++) {
                try {
                    found = worldClass.getMethod(WORLD_SERVER_PARTICLE_METHODS[i],
                            String.class, Double.TYPE, Double.TYPE, Double.TYPE, Integer.TYPE,
                            Double.TYPE, Double.TYPE, Double.TYPE, Double.TYPE);
                } catch (Exception ignored) {
                    // Try the alternate MCP/SRG name before failing closed.
                }
            }
            particleWorldClass = worldClass;
            particleBroadcast = found;
            return found;
        }
    }

    private static String particleFor(String id) {
        if (id.startsWith("saiyan.ultra_instinct")) return "witchMagic";
        if (id.endsWith("ssj4") || id.endsWith("beast")) return "flame";
        if (id.endsWith("golden_oozaru") || id.endsWith("golden")
                || id.endsWith("golden_full_power")) return "reddust";
        if (id.endsWith("god") || id.endsWith("blue") || id.endsWith("blue_evolution")) return "portal";
        if (id.endsWith("black")) return "smoke";
        if (id.endsWith("ozaru") || id.endsWith("giant")) return "largeexplode";
        if (id.startsWith("majin.")) return "spell";
        if (id.startsWith("human.kaioken")) return "reddust";
        return "crit";
    }
}
