package com.dragonascension.core;

import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.event.PlayerDataEvents;
import net.minecraft.entity.player.EntityPlayer;

/** Server-side energy billing. It fails closed when no verified energy bridge exists. */
public final class TransformationEnergyService {
    private static final int BILLING_INTERVAL_TICKS = 20;

    private TransformationEnergyService() { }

    /**
     * Bills one second of an already-confirmed transformation. The adapter must
     * perform an atomic subtraction; this service never guesses JRMCore setters.
     */
    public static boolean billConfirmedSecond(EntityPlayer player, String evolutionId) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote
                || evolutionId == null || evolutionId.length() == 0) return false;
        if (!TransformationSessionService.isActive(player, evolutionId)) return false;
        EvolutionDefinition definition = EvolutionRegistry.get(evolutionId);
        if (definition == null) return false;

        PlayerEvolutionData data = PlayerDataEvents.get(player);
        if (!data.isUnlocked(evolutionId)) return false;
        String race = EvolutionUnlockService.getVerifiedRaceKey(player, data);
        if (race == null || !definition.getRaceKey().equals(race)) {
            TransformationSessionService.end(player, evolutionId);
            return false;
        }
        if (!IntegrationManager.hasPlayerEnergyAdapter()) return false;

        double cost = TransformationEnergyPolicy.costForTicks(
                BILLING_INTERVAL_TICKS, data.getMastery(evolutionId));
        return cost > 0.0D && IntegrationManager.consumePlayerEnergy(player, cost);
    }

    public static int getBillingIntervalTicks() { return BILLING_INTERVAL_TICKS; }
}
