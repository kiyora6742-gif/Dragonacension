package com.dragonascension.core;

public final class EvolutionValidator {
    private EvolutionValidator() { }

    /**
     * @param playerLevel nível real do jogador; null significa que a integração
     *                    responsável por fornecê-lo ainda não está disponível.
     */
    public static String validate(EvolutionDefinition definition, String playerRaceKey,
            Integer playerLevel, PlayerEvolutionData data) {
        if (definition == null) return "Evolução inexistente.";
        if (data == null) return "Dados de evolução indisponíveis.";
        if (!definition.isEnabled()) return "Evolução desativada.";
        if (playerRaceKey == null || !definition.getRaceKey().equals(playerRaceKey))
            return "Raça incompatível.";
        if (definition.getParentId() != null) {
            if (!data.isUnlocked(definition.getParentId()))
                return "Pré-requisito anterior não desbloqueado.";
            // O domínio exigido por uma evolução encadeada é o domínio da forma anterior.
            // Isso evita exigir domínio de uma forma que ainda nem foi desbloqueada.
            if (data.getMastery(definition.getParentId()) < definition.getRequiredMastery())
                return "Domínio insuficiente na evolução anterior.";
        } else if (data.getMastery(definition.getId()) < definition.getRequiredMastery()) {
            // Em evoluções-raiz, o domínio precisa vir de um sistema de progresso externo
            // ou de administração enquanto a integração DBC/JRMCore não estiver pronta.
            return "Domínio insuficiente.";
        }
        if (definition.getRequiredLevel() > 0 && playerLevel == null)
            return "Nível não verificável: integração com JRMCore ainda não disponível.";
        if (playerLevel != null && playerLevel.intValue() < definition.getRequiredLevel())
            return "Nível insuficiente.";
        if (definition.requiresTraining() && !data.hasTraining(definition.getId()))
            return "Treinamento necessário.";
        if (definition.requiresChallenge() && !data.hasChallenge(definition.getId()))
            return "Desafio necessário.";
        return null;
    }
}
