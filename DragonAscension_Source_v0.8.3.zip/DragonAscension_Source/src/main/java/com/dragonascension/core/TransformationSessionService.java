package com.dragonascension.core;

import com.dragonascension.event.PlayerDataEvents;
import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.compat.TransformationReadResult;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Neutral transformation-session API.
 *
 * A verified DBC/DBC Additions adapter must call begin/end only after it has
 * confirmed the real in-game form. The base mod deliberately does not guess
 * transformation IDs or infer the active form from unrelated player stats.
 */
public final class TransformationSessionService {
    private TransformationSessionService() { }

    /**
     * Marks a registered, already-unlocked evolution as active.
     * Server-side only.
     */
    public static boolean begin(EntityPlayer player, String evolutionId) {
        if (!isServerPlayer(player) || evolutionId == null) return false;
        EvolutionDefinition definition = EvolutionRegistry.get(evolutionId);
        if (definition == null) return false;

        PlayerEvolutionData data = PlayerDataEvents.get(player);
        if (!data.isUnlocked(evolutionId)) return false;
        String raceKey = EvolutionUnlockService.getVerifiedRaceKey(player, data);
        if (raceKey == null || !definition.getRaceKey().equals(raceKey)) return false;

        data.setActiveTransformationId(evolutionId);
        PlayerDataEvents.save(player, data);
        return true;
    }

    /**
     * Ends the current session. If expectedEvolutionId is supplied, it must
     * match the active evolution, preventing stale callbacks from ending a
     * different form's session.
     */
    public static boolean end(EntityPlayer player, String expectedEvolutionId) {
        if (!isServerPlayer(player)) return false;
        PlayerEvolutionData data = PlayerDataEvents.get(player);
        String active = data.getActiveTransformationId();
        if (active == null || active.length() == 0) return false;
        if (expectedEvolutionId != null && !expectedEvolutionId.equals(active)) return false;

        data.setActiveTransformationId("");
        PlayerDataEvents.save(player, data);
        return true;
    }

    public static boolean isActive(EntityPlayer player, String evolutionId) {
        if (player == null || evolutionId == null) return false;
        PlayerEvolutionData data = PlayerDataEvents.get(player);
        return evolutionId.equals(data.getActiveTransformationId());
    }

    /**
     * Records one confirmed-use callback. The adapter supplies the mastery
     * award after applying its own verified timing/balance rules.
     */
    public static boolean recordConfirmedUse(EntityPlayer player,
            String evolutionId, double masteryAward) {
        if (!isServerPlayer(player) || evolutionId == null) return false;
        if (!isActive(player, evolutionId)) return false;

        PlayerEvolutionData data = PlayerDataEvents.get(player);
        EvolutionDefinition definition = EvolutionRegistry.get(evolutionId);
        if (definition == null || !data.isUnlocked(evolutionId)) return false;
        String raceKey = EvolutionUnlockService.getVerifiedRaceKey(player, data);
        if (raceKey == null || !definition.getRaceKey().equals(raceKey)) {
            end(player, evolutionId);
            return false;
        }
        if (!MasteryProgression.recordTransformationUse(player, evolutionId, masteryAward)) {
            return false;
        }

        // MasteryProgression persists its own fresh data snapshot. Re-read it
        // before updating the counter so we do not overwrite the new mastery.
        PlayerEvolutionData updated = PlayerDataEvents.get(player);
        updated.incrementConfirmedTransformationUseEvents();
        PlayerDataEvents.save(player, updated);
        return true;
    }


    /**
     * Reconciles the saved session with a verified external adapter.
     * Unknown IDs are rejected; no guessed form mapping is performed.
     */
    public static boolean synchronizeFromAdapter(EntityPlayer player) {
        if (!isServerPlayer(player) || !IntegrationManager.hasTransformationAdapter()) return false;
        TransformationReadResult result = IntegrationManager.readTransformation(player);
        if (result.getStatus() == TransformationReadResult.Status.UNKNOWN) return false;
        if (result.getStatus() == TransformationReadResult.Status.INACTIVE) {
            end(player, null);
            return true;
        }

        String externalId = result.getEvolutionId();
        EvolutionDefinition definition = EvolutionRegistry.get(externalId);
        if (definition == null) {
            // The adapter positively reported ACTIVE, but this addon does not
            // recognize the external ID. Do not preserve bonuses/session data
            // from the previous form: this is a definite rejected state.
            end(player, null);
            return true;
        }

        PlayerEvolutionData data = PlayerDataEvents.get(player);
        String raceKey = EvolutionUnlockService.getVerifiedRaceKey(player, data);
        if (!data.isUnlocked(externalId) || raceKey == null
                || !definition.getRaceKey().equals(raceKey)) {
            // The adapter returned a definite ACTIVE state, but Dragon
            // Ascension rejected it (locked form or wrong race). Clear the
            // old session and report a completed reconciliation so callers
            // also remove modifiers belonging to the previous form.
            end(player, null);
            return true;
        }

        String currentId = data.getActiveTransformationId();
        if (externalId.equals(currentId)) {
            return true;
        }

        if (currentId != null && currentId.length() > 0) {
            end(player, currentId);
        }
        return begin(player, externalId);
    }

    private static boolean isServerPlayer(EntityPlayer player) {
        return player != null && player.worldObj != null && !player.worldObj.isRemote;
    }
}
