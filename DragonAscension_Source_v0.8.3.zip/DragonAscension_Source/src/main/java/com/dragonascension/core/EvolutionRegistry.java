package com.dragonascension.core;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class EvolutionRegistry {
    private static final Map<String, EvolutionDefinition> DEFINITIONS =
            new LinkedHashMap<String, EvolutionDefinition>();
    private static boolean builtInsRegistered;

    private EvolutionRegistry() { }

    public static synchronized void register(EvolutionDefinition definition) {
        if (definition == null) throw new IllegalArgumentException("definition nula");
        if (DEFINITIONS.containsKey(definition.getId()))
            throw new IllegalArgumentException("ID de evolução duplicado: " + definition.getId());
        DEFINITIONS.put(definition.getId(), definition);
    }

    public static synchronized EvolutionDefinition get(String id) {
        return DEFINITIONS.get(id);
    }

    public static synchronized Collection<EvolutionDefinition> all() {
        return Collections.unmodifiableCollection(DEFINITIONS.values());
    }

    /** Retorna as evoluções de uma raça interna, preservando a ordem de registro. */
    public static synchronized Collection<EvolutionDefinition> byRace(String raceKey) {
        java.util.List<EvolutionDefinition> result = new java.util.ArrayList<EvolutionDefinition>();
        if (raceKey == null) return Collections.unmodifiableList(result);
        for (EvolutionDefinition definition : DEFINITIONS.values()) {
            if (raceKey.equals(definition.getRaceKey())) result.add(definition);
        }
        return Collections.unmodifiableList(result);
    }

    /** Retorna os filhos diretos de uma evolução, preservando a ordem de registro. */
    public static synchronized Collection<EvolutionDefinition> childrenOf(String parentId) {
        java.util.List<EvolutionDefinition> result = new java.util.ArrayList<EvolutionDefinition>();
        for (EvolutionDefinition definition : DEFINITIONS.values()) {
            if (parentId == null ? definition.getParentId() == null
                    : parentId.equals(definition.getParentId())) {
                result.add(definition);
            }
        }
        return Collections.unmodifiableList(result);
    }

    public static synchronized int countByRace(String raceKey) {
        return byRace(raceKey).size();
    }

    public static synchronized void registerBuiltInDefinitions() {
        if (builtInsRegistered) return;

        // Chaves internas do Dragon Ascension. Não são IDs raciais/formas do DBC.
        // Saiyajin
        add("saiyan.ssj", "Super Saiyajin", "saiyan", null, 20, 0, false, false);
        add("saiyan.ssj_full_power", "Super Saiyajin Full Power", "saiyan", "saiyan.ssj", 0, 60, true, false);
        add("saiyan.ssj2", "Super Saiyajin 2", "saiyan", "saiyan.ssj", 0, 50, false, false);
        add("saiyan.ssj3", "Super Saiyajin 3", "saiyan", "saiyan.ssj2", 0, 75, true, false);
        add("saiyan.potential", "Potencial Despertado", "saiyan", null, 0, 75, true, true);
        add("saiyan.god", "Super Saiyajin God", "saiyan", null, 0, 80, true, true);
        add("saiyan.blue", "Super Saiyajin Blue", "saiyan", "saiyan.god", 0, 70, true, true);
        add("saiyan.blue_evolution", "Blue Evolution", "saiyan", "saiyan.blue", 0, 90, true, true);
        // Ramificação Oozaru: SSJ4 depende da evolução do Oozaru Dourado.
        add("saiyan.ozaru", "Oozaru", "saiyan", null, 10, 0, true, false);
        add("saiyan.golden_oozaru", "Oozaru Dourado", "saiyan", "saiyan.ozaru", 0, 70, true, true);
        add("saiyan.ssj4", "Super Saiyajin 4", "saiyan", "saiyan.golden_oozaru", 0, 85, true, true);

        // Instinto Superior permanece em uma ramificação independente da árvore principal.
        add("saiyan.ultra_instinct_sign", "Instinto Superior (Sinal)", "saiyan", null, 0, 85, true, true);
        add("saiyan.ultra_instinct", "Instinto Superior", "saiyan", "saiyan.ultra_instinct_sign", 0, 100, true, true);

        // Meio-saiyajin
        add("half_saiyan.ssj", "Super Saiyajin", "half_saiyan", null, 15, 0, false, false);
        add("half_saiyan.ssj2", "Super Saiyajin 2", "half_saiyan", "half_saiyan.ssj", 0, 50, false, false);
        add("half_saiyan.potential", "Potential Unleashed", "half_saiyan", null, 0, 75, true, true);
        add("half_saiyan.beast", "Beast", "half_saiyan", "half_saiyan.potential", 0, 95, true, true);
        add("half_saiyan.god", "Super Saiyajin God", "half_saiyan", null, 0, 80, true, true);
        add("half_saiyan.blue", "Super Saiyajin Blue", "half_saiyan", "half_saiyan.god", 0, 70, true, true);

        // Arcosiano
        add("arcosian.second_form", "Segunda Forma", "arcosian", null, 10, 0, false, false);
        add("arcosian.third_form", "Terceira Forma", "arcosian", "arcosian.second_form", 0, 35, false, false);
        add("arcosian.final_form", "Forma Final", "arcosian", "arcosian.third_form", 0, 50, false, false);
        add("arcosian.powered_final", "Poder Total", "arcosian", "arcosian.final_form", 0, 70, true, false);
        add("arcosian.golden", "Golden", "arcosian", "arcosian.final_form", 0, 75, true, true);
        add("arcosian.golden_full_power", "Golden Full Power", "arcosian", "arcosian.golden", 0, 90, true, true);
        add("arcosian.black", "Black Freeza", "arcosian", "arcosian.golden_full_power", 0, 100, true, true);

        // Namekuseijin
        add("namekian.giant", "Forma Gigante", "namekian", null, 10, 0, true, false);
        add("namekian.fusion", "Fusão Namekuseijin", "namekian", null, 0, 60, true, true);
        add("namekian.potential", "Potencial Despertado", "namekian", "namekian.fusion", 0, 75, true, true);
        add("namekian.orange", "Orange Namekian", "namekian", "namekian.potential", 0, 100, true, true);

        // Humano
        add("human.kaioken", "Kaioken", "human", null, 10, 0, true, false);
        add("human.kaioken_advanced", "Kaioken Avançado", "human", "human.kaioken", 0, 70, true, true);
        add("human.potential", "Potencial Despertado", "human", null, 0, 75, true, true);
        add("human.maximum", "Poder Máximo Humano", "human", "human.potential", 0, 95, true, true);

        // Majin
        add("majin.super", "Super Majin", "majin", null, 15, 0, true, false);
        add("majin.pure", "Pure Majin", "majin", "majin.super", 0, 85, true, true);
        add("majin.absorption", "Absorção", "majin", null, 0, 60, true, true);
        add("majin.potential", "Potencial Despertado", "majin", null, 0, 75, true, true);

        builtInsRegistered = true;
    }

    /**
     * Verifica a integridade da árvore sem depender de APIs do Minecraft/DBC.
     * Retorna uma lista vazia quando todas as definições estão estruturalmente corretas.
     */
    public static synchronized java.util.List<String> audit() {
        java.util.List<String> errors = new java.util.ArrayList<String>();
        for (EvolutionDefinition definition : DEFINITIONS.values()) {
            String parentId = definition.getParentId();
            if (parentId == null) continue;
            EvolutionDefinition parent = DEFINITIONS.get(parentId);
            if (parent == null) {
                errors.add(definition.getId() + ": pré-requisito inexistente " + parentId);
                continue;
            }
            if (!definition.getRaceKey().equals(parent.getRaceKey())) {
                errors.add(definition.getId() + ": pré-requisito pertence a outra raça");
            }
            if (definition.getId().equals(parentId)) {
                errors.add(definition.getId() + ": não pode ser pai de si mesma");
            }
            java.util.Set<String> visited = new java.util.HashSet<String>();
            EvolutionDefinition cursor = definition;
            while (cursor != null && cursor.getParentId() != null) {
                if (!visited.add(cursor.getId())) {
                    errors.add(definition.getId() + ": ciclo detectado na árvore");
                    break;
                }
                cursor = DEFINITIONS.get(cursor.getParentId());
            }
        }
        return java.util.Collections.unmodifiableList(errors);
    }

    private static void add(String id, String name, String race, String parent,
            int level, double mastery, boolean training, boolean challenge) {
        register(new EvolutionDefinition(id, name, race, parent, level, mastery,
                training, challenge, true));
    }
}
