package com.dragonascension.core;

import java.util.UUID;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;

/** Applies only Dragon Ascension-owned vanilla attribute modifiers. */
public final class TransformationEffectService {
    private static final UUID ATTACK_UUID = UUID.fromString("3f47dcb2-92f1-4c89-9b61-4e0e3d1f1001");
    private static final UUID SPEED_UUID  = UUID.fromString("3f47dcb2-92f1-4c89-9b61-4e0e3d1f1002");
    private static final String ATTACK_NAME = "Dragon Ascension transformation attack";
    private static final String SPEED_NAME = "Dragon Ascension transformation speed";

    private TransformationEffectService() { }

    public static void refresh(EntityPlayer player, String evolutionId) {
        if (player == null || player.worldObj == null || player.worldObj.isRemote) return;
        IAttributeInstance attack = player.getEntityAttribute(SharedMonsterAttributes.attackDamage);
        IAttributeInstance speed = player.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
        if (attack == null || speed == null) return;
        removeOwned(attack, ATTACK_UUID);
        removeOwned(speed, SPEED_UUID);
        if (evolutionId == null || evolutionId.length() == 0) return;
        EvolutionDefinition definition = EvolutionRegistry.get(evolutionId);
        if (definition == null || !definition.isEnabled()) return;

        double attackBonus = attackBonus(evolutionId);
        double speedBonus = speedBonus(evolutionId);
        if (attackBonus > 0.0D) {
            attack.applyModifier(new AttributeModifier(ATTACK_UUID, ATTACK_NAME, attackBonus, 0));
        }
        if (speedBonus > 0.0D) {
            speed.applyModifier(new AttributeModifier(SPEED_UUID, SPEED_NAME, speedBonus, 2));
        }
    }

    public static void clear(EntityPlayer player) { refresh(player, null); }

    private static void removeOwned(IAttributeInstance attribute, UUID id) {
        AttributeModifier modifier = attribute.getModifier(id);
        if (modifier != null) attribute.removeModifier(modifier);
    }

    private static double attackBonus(String id) {
        if (id.endsWith("ultra_instinct")) return 5.0D;
        if (id.endsWith("ssj4") || id.endsWith("beast") || id.endsWith("black")) return 4.0D;
        if (id.endsWith("blue_evolution") || id.endsWith("golden_full_power")) return 3.5D;
        if (id.endsWith("ssj3") || id.endsWith("golden") || id.endsWith("orange")) return 3.0D;
        if (id.endsWith("ssj2") || id.endsWith("blue") || id.endsWith("god")) return 2.0D;
        if (id.endsWith("ssj") || id.endsWith("final_form") || id.endsWith("kaioken")) return 1.0D;
        if (id.contains("ozaru") || id.endsWith("giant")) return 2.5D;
        if (id.startsWith("majin.")) return 1.5D;
        return 0.5D;
    }

    private static double speedBonus(String id) {
        if (id.endsWith("ultra_instinct") || id.endsWith("ultra_instinct_sign")) return 0.30D;
        if (id.endsWith("ssj4") || id.endsWith("beast") || id.endsWith("black")) return 0.22D;
        if (id.endsWith("blue_evolution") || id.endsWith("golden_full_power")) return 0.18D;
        if (id.endsWith("ssj3") || id.endsWith("golden") || id.endsWith("orange")) return 0.14D;
        if (id.endsWith("ssj2") || id.endsWith("blue") || id.endsWith("god")) return 0.10D;
        if (id.endsWith("ssj") || id.endsWith("final_form") || id.endsWith("kaioken")) return 0.06D;
        if (id.contains("ozaru") || id.endsWith("giant")) return 0.02D;
        return 0.04D;
    }
}
