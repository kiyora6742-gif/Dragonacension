package com.dragonascension.core;

/**
 * Política neutra de custo de energia por tick.
 * Não acessa JRMCore: o adaptador de energia real deve aplicar o custo
 * somente depois de confirmar a forma ativa no servidor.
 */
public final class TransformationEnergyPolicy {
    private static final double BASE_COST_PER_TICK = 1.0D;
    private static final double MIN_COST_PER_TICK = 0.25D;
    private static final double MAX_COST_PER_TICK = 8.0D;
    private static final double MASTERY_DISCOUNT = 0.50D;

    private TransformationEnergyPolicy() { }

    /**
     * Calcula o custo total de um intervalo. Domínio reduz o custo gradualmente,
     * até 50% no domínio máximo. Entradas inválidas resultam em custo zero.
     */
    public static double costForTicks(int ticks, double mastery) {
        if (ticks <= 0 || Double.isNaN(mastery) || Double.isInfinite(mastery)) return 0.0D;
        double safeMastery = Math.max(0.0D, Math.min(100.0D, mastery));
        double multiplier = 1.0D - (MASTERY_DISCOUNT * safeMastery / 100.0D);
        double perTick = BASE_COST_PER_TICK * multiplier;
        perTick = Math.max(MIN_COST_PER_TICK, Math.min(MAX_COST_PER_TICK, perTick));
        return perTick * ticks;
    }

    public static double getBaseCostPerTick() { return BASE_COST_PER_TICK; }
    public static double getMinimumCostPerTick() { return MIN_COST_PER_TICK; }
    public static double getMaximumCostPerTick() { return MAX_COST_PER_TICK; }
}
