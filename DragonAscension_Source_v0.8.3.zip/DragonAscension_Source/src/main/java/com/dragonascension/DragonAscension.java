package com.dragonascension;

import com.dragonascension.core.EvolutionRegistry;
import com.dragonascension.compat.DbcAdditionsTransformationAdapter;
import com.dragonascension.compat.DbcNativeTransformationAdapter;
import com.dragonascension.compat.CompositeTransformationAdapter;
import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.compat.JrmCorePlayerContextAdapter;
import com.dragonascension.compat.JrmCoreEnergyAdapter;
import com.dragonascension.proxy.CommonProxy;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLServerStartingEvent;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import com.dragonascension.command.CommandDragonAscension;
import com.dragonascension.event.PlayerDataEvents;
import com.dragonascension.event.TransformationSyncEvents;
import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = DragonAscension.MODID, name = DragonAscension.NAME, version = DragonAscension.VERSION)
public class DragonAscension {
    public static final String MODID = "dragonascension";
    public static final String NAME = "Dragon Ascension";
    public static final String VERSION = "0.8.1";

    @Instance(MODID)
    public static DragonAscension instance;

    @SidedProxy(clientSide = "com.dragonascension.proxy.ClientProxy",
                serverSide = "com.dragonascension.proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EvolutionRegistry.registerBuiltInDefinitions();
        if (IntegrationManager.isJRMCorePresent()
                && IntegrationManager.isJRMCoreApiClassVisible()) {
            IntegrationManager.registerPlayerContextAdapter(new JrmCorePlayerContextAdapter());
            JrmCoreEnergyAdapter energyAdapter = new JrmCoreEnergyAdapter();
            if (energyAdapter.isAvailable()) {
                IntegrationManager.registerPlayerEnergyAdapter(energyAdapter);
            }
        }
        boolean additionsAvailable = IntegrationManager.isAdditionsPresent()
                && IntegrationManager.isAdditionsApiClassVisible();
        boolean nativeDbcAvailable = IntegrationManager.isDragonBlockCPresent()
                && IntegrationManager.isDragonBlockCApiClassVisible()
                && IntegrationManager.isJRMCorePresent()
                && IntegrationManager.isJRMCoreApiClassVisible();
        if (additionsAvailable || nativeDbcAvailable) {
            IntegrationManager.registerTransformationAdapter(
                    new CompositeTransformationAdapter(
                            additionsAvailable ? new DbcAdditionsTransformationAdapter() : null,
                            nativeDbcAvailable ? new DbcNativeTransformationAdapter() : null));
        }
        PlayerDataEvents playerDataEvents = new PlayerDataEvents();
        MinecraftForge.EVENT_BUS.register(playerDataEvents);
        FMLCommonHandler.instance().bus().register(playerDataEvents);
        FMLCommonHandler.instance().bus().register(new TransformationSyncEvents());
        proxy.preInit();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init();
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new CommandDragonAscension());
    }
}
