package com.dragonascension.event;

import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.core.TransformationSessionService;
import com.dragonascension.core.PlayerEvolutionData;
import com.dragonascension.core.TransformationEnergyService;
import com.dragonascension.core.TransformationEffectService;
import com.dragonascension.core.TransformationAuraService;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.common.gameevent.TickEvent.PlayerTickEvent;
import net.minecraft.entity.player.EntityPlayer;

/**
 * Optional bridge that polls a registered transformation adapter.
 * No external mod classes are referenced here.
 */
public final class TransformationSyncEvents {
    @SubscribeEvent
    public void onPlayerTick(PlayerTickEvent event) {
        if (event == null || event.phase != TickEvent.Phase.END) return;
        EntityPlayer player = event.player;
        if (player == null || player.worldObj == null || player.worldObj.isRemote) return;
        if ((player.ticksExisted % 5) == 0) {
            PlayerEvolutionData auraData = PlayerDataEvents.get(player);
            TransformationAuraService.emit(player, auraData.getActiveTransformationId());
        }
        if ((player.ticksExisted % 20) != 0) return;
        boolean adapterAvailable = IntegrationManager.hasTransformationAdapter();
        if (adapterAvailable) {
            boolean synchronizedState = TransformationSessionService.synchronizeFromAdapter(player);
            if (!synchronizedState) return; // UNKNOWN: preserve current effects until state is knowable.
            // A definite but rejected ACTIVE form also clears the saved session;
            // refresh below removes any modifiers left by the previous form.
        }

        PlayerEvolutionData data = PlayerDataEvents.get(player);
        String activeId = data.getActiveTransformationId();
        TransformationEffectService.refresh(player, activeId);
        if (activeId != null && activeId.length() > 0 && adapterAvailable) {
            // One confirmed server-side sample per second. The progression API
            // enforces unlock state, finite values, and a per-call upper bound.
            if (TransformationEnergyService.billConfirmedSecond(player, activeId)) {
                TransformationSessionService.recordConfirmedUse(player, activeId, 0.02D);
            }
        }
    }
}
