package com.dragonascension.event;

import com.dragonascension.core.PlayerEvolutionData;
import com.dragonascension.compat.IntegrationManager;
import com.dragonascension.compat.PlayerContext;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.event.entity.player.PlayerEvent;

public class PlayerDataEvents {
    private static final String KEY = "DragonAscension";

    public static PlayerEvolutionData get(EntityPlayer player) {
        if (player == null) return new PlayerEvolutionData();
        NBTTagCompound persisted = player.getEntityData().getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        NBTTagCompound root = new NBTTagCompound();
        root.setTag(KEY, persisted.getCompoundTag(KEY));
        PlayerEvolutionData data = new PlayerEvolutionData();
        data.readFromNBT(root);
        return data;
    }

    public static void save(EntityPlayer player, PlayerEvolutionData data) {
        if (player == null || data == null) return;
        NBTTagCompound entityData = player.getEntityData();
        NBTTagCompound persisted = entityData.getCompoundTag(EntityPlayer.PERSISTED_NBT_TAG);
        NBTTagCompound root = new NBTTagCompound();
        data.writeToNBT(root);
        persisted.setTag(KEY, root.getCompoundTag(KEY));
        entityData.setTag(EntityPlayer.PERSISTED_NBT_TAG, persisted);
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone event) {
        if (event == null || event.original == null || event.entityPlayer == null) return;
        PlayerEvolutionData oldData = get(event.original);
        // The old form may not survive death/respawn; preserve progression but
        // never copy a possibly stale "currently transformed" marker.
        oldData.clearActiveTransformation();
        save(event.entityPlayer, oldData);
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerLoggedInEvent event) {
        if (event == null || event.player == null) return;
        PlayerEvolutionData data = get(event.player);
        boolean changed = false;

        // JRMCore's per-player API is authoritative for the current race.
        PlayerContext context = IntegrationManager.readPlayerContext(event.player);
        if (context != null && context.hasRace()
                && !context.getRaceKey().equals(data.getRaceKey())) {
            data.setRaceKey(context.getRaceKey());
            changed = true;
        }

        // A saved marker cannot prove the external mod still has this form
        // active after a disconnect or server restart.
        if (data.getActiveTransformationId() != null
                && data.getActiveTransformationId().length() > 0) {
            data.clearActiveTransformation();
            changed = true;
        }
        if (changed) save(event.player, data);
    }
}
