@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==============================================
echo Dragon Ascension - build Minecraft 1.7.10
echo Requisitos: JDK 8, Gradle 6.9.1 e internet
echo ==============================================

if not defined JAVA_HOME (
  echo ERRO: JAVA_HOME nao esta definido. Aponte para um JDK 8.
  exit /b 1
)
if not exist "%JAVA_HOME%\bin\javac.exe" (
  echo ERRO: javac.exe nao encontrado em JAVA_HOME. E necessario JDK, nao apenas JRE.
  exit /b 1
)
if not exist "%JAVA_HOME%\bin\java.exe" (
  echo ERRO: java.exe nao encontrado em JAVA_HOME.
  exit /b 1
)
set PATH=%JAVA_HOME%\bin;%PATH%
where gradle >nul 2>nul || (echo ERRO: Gradle nao encontrado no PATH. Instale Gradle 6.9.1. & exit /b 1)

for /f "tokens=2" %%V in ('"%JAVA_HOME%\bin\java.exe" -version 2^>^&1 ^| findstr /i "version"') do set JAVA_VERSION=%%~V
for /f "tokens=2" %%V in ('gradle --version ^| findstr /b /c:"Gradle "') do set GRADLE_VERSION=%%V
for /f "tokens=2" %%V in ('gradle --version ^| findstr /b /c:"JVM:"') do set GRADLE_JVM=%%V
for /f "tokens=2 delims== " %%V in ('findstr /r /c:"^[ ]*version[ ]*=" build.gradle') do set PROJECT_VERSION=%%~V
set PROJECT_VERSION=%PROJECT_VERSION:"=%
if not defined PROJECT_VERSION (echo ERRO: nao foi possivel ler a versao do build.gradle. & exit /b 1)
set EXPECTED_JAR=build\libs\DragonAscension-%PROJECT_VERSION%.jar

echo Java detectado: %JAVA_VERSION%
"%JAVA_HOME%\bin\javac.exe" -version
echo Gradle detectado: %GRADLE_VERSION% (JVM: %GRADLE_JVM%)
echo.

echo %JAVA_VERSION% | findstr /b /c:"1.8" >nul || (echo ERRO: esta compilacao exige JDK 8. & exit /b 1)
echo %GRADLE_VERSION% | findstr /b /c:"6.9.1" >nul || (echo ERRO: esta configuracao espera Gradle 6.9.1. & exit /b 1)
echo %GRADLE_JVM% | findstr /b /c:"1.8" >nul || (echo ERRO: o Gradle nao esta executando com Java 8. Confira JAVA_HOME. & exit /b 1)

echo [0/3] Validando a configuracao do projeto...
gradle --no-daemon help --stacktrace || exit /b 1

echo [1/3] Preparando workspace Forge 1.7.10...
gradle --no-daemon setupDecompWorkspace --stacktrace || exit /b 1

echo [2/3] Compilando Dragon Ascension...
gradle --no-daemon clean build --stacktrace || exit /b 1

if not exist "%EXPECTED_JAR%" (
  echo ERRO: build terminou sem gerar o JAR esperado.
  exit /b 1
)
echo Build concluido:
dir "%EXPECTED_JAR%"
endlocal
