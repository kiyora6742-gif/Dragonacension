# Compilar Dragon Ascension pelo GitHub Actions

Este projeto inclui um workflow em `.github/workflows/build.yml` para tentar compilar o mod em um runner Ubuntu 22.04 com JDK 8 e Gradle 6.9.1.

## Como usar

1. Entre no GitHub e crie um repositório vazio chamado `DragonAscension`.
2. No celular, abra o repositório e use **Add file → Upload files**.
3. Extraia este ZIP e envie **o conteúdo de dentro da pasta `DragonAscension_Source`**, incluindo a pasta oculta `.github`. Não envie apenas o ZIP dentro do repositório.
4. Faça o commit na branch `main`.
5. Abra a aba **Actions** no repositório e selecione **Build Dragon Ascension**.
6. Abra a execução mais recente. Se todos os passos passarem, baixe o artefato **DragonAscension-jar** em **Artifacts**.

## Importante

- O workflow automatiza a tentativa de build; ele não significa que o JAR já foi compilado.
- O ForgeGradle para Minecraft 1.7.10 é legado. Downloads, repositórios ou incompatibilidades do plugin podem fazer a execução falhar mesmo com Java e Gradle corretos.
- Se falhar, abra a execução em Actions e envie aqui o texto do primeiro passo marcado como erro (ou o log completo). Não instale nem execute JARs desconhecidos.
- Um JAR só deve ser considerado pronto depois de o workflow terminar com sucesso e o arquivo gerado ser verificado e testado no Minecraft 1.7.10 com as versões compatíveis de Forge, JRMCore e DBC.
