# Integração DBC / JRMCore / DBC Additions

## Estado real da versão 0.3.0

O núcleo Dragon Ascension continua sem dependência de classes externas. O contrato
`ITransformationAdapter` é o único ponto de entrada para um módulo de compatibilidade.
O adaptador deve ser implementado e registrado por código que compile contra os JARs
exatos instalados no servidor.

## Contrato obrigatório

- `getId()`: identificador estável do provedor.
- `isAvailable()`: verifica em runtime se as classes e o estado necessário existem.
- `readTransformation(player)`: retorna `ACTIVE` com um ID interno registrado,
  `INACTIVE` somente quando o estado normal foi confirmado, ou `UNKNOWN` quando
  a leitura não foi possível ou a forma não tem mapeamento seguro.
- `UNKNOWN` nunca deve ser interpretado como `INACTIVE`: uma falha temporária de
  reflection/API não pode encerrar uma sessão previamente confirmada.
- Nunca retornar IDs brutos do DBC/DBC Additions sem mapeamento explícito.
- Nunca ler estado client-side para atualizar progressão.
- Não conceder domínio apenas por consultar a forma: o adaptador deve chamar
  `recordConfirmedUse` com uma regra de ganho validada e limitada.

## Por que não há adaptador DBC embutido nesta entrega

As APIs legadas têm assinaturas e dependências binárias específicas. Sem os JARs
exatos usados pelo servidor e sem uma compilação ForgeGradle, declarar chamadas
reflexivas ou nomes de métodos como integração funcional seria inseguro. A
presença de uma classe não comprova assinatura, visibilidade ou semântica.

## Validação antes de ativar um adaptador

1. Compilar contra Minecraft 1.7.10 / Forge 10.13.4.1614 e os JARs exatos.
2. Verificar raça e forma ativa para cada raça suportada.
3. Verificar transformações, descida, morte, logout e troca de dimensão.
4. Confirmar que formas não desbloqueadas não iniciam sessão.
5. Confirmar que domínio só progride durante uso confirmado no servidor.
6. Testar servidor dedicado e cliente integrado.


## Adaptador DBC Additions 1.8.10 na v0.3.1

A versão 0.3.1 inclui `DbcAdditionsTransformationAdapter`, que consulta por
reflection as assinaturas verificadas nos JARs 1.8.10 enviados:

- `DBCAPlayer.get(EntityPlayer)`
- campo público `DBAForm`
- `DBCAPlayer.getRace()`
- `DBCAForms.getForm(int)`
- `DBCAForm.getName()`
- `JRMCoreH.isRaceHalfSaiyan(int)`, `isRaceNamekian(int)` e `isRaceArcosian(int)`

O adaptador reconhece somente nomes internos conhecidos: Beast, Potential
Unleashed Namekian, Orange, as formas Arcosianas Imperfect/Semi Perfect/Perfect/
Full Power/Super Perfect/Golden Perfect/Black. Qualquer forma desconhecida ou
customizada retorna null, sem tentar adivinhar o mapeamento.

O adaptador é registrado automaticamente no preInit quando DBC Additions e as
classes de API estão visíveis. O polling server-side já existente sincroniza
somente evoluções internas que o jogador desbloqueou.

Limite importante: esta implementação cobre as formas customizadas expostas por
DBCAPlayer.DBAForm. Ela ainda não mapeia todas as transformações nativas do DBC
lidas por jrmcState; isso exige uma tabela de estados nativos validada por raça.


## JRMCore 1.3.51 — contexto automático e domínio

A v0.4.0 adiciona `JrmCorePlayerContextAdapter`, usando assinaturas verificadas
em JRMCore 1.3.51:

- `getByte(EntityPlayer, String)` com `jrmcRace`
- `getInt(EntityPlayer, String)` com `jrmcEnrgy`
- `PlyrAttrbts(EntityPlayer)` e `getPlayerLevel(int[])`
- `isRaceFullSaiyan(int)`, `isRaceHalfSaiyan(int)`, `isRaceHuman(int)`,
  `isRaceNamekian(int)`, `isRaceArcosian(int)` e `isRaceMajin(int)`

A raça é sincronizada no login. O nível deriva dos seis atributos individuais
por meio do método oficial `getPlayerLevel(int[])`; energia usa a chave per-player
`jrmcEnrgy`. Não são usados snapshots estáticos mutáveis do JRMCore.

Quando um adaptador de transformação confirma uma forma já desbloqueada, o evento
server-side registra 0,02 ponto de domínio por segundo. Uma sessão sem forma
confirmada, uma forma desconhecida ou uma forma não desbloqueada não recebe domínio.


## v0.5.2 — contrato tri-state

A sincronização diferencia explicitamente forma ativa, inatividade confirmada e
leitura indeterminada. Isso evita que uma exceção de reflection, uma API
indisponível ou uma forma ainda não mapeada seja confundida com a saída de uma
transformação. No adaptador composto, qualquer forma ativa reconhecida tem
prioridade; a inatividade só é confirmada quando os adaptadores disponíveis
concordam. O comando de diagnóstico exibe os três estados.


## v0.6.0 — ponte de energia e efeitos de transformação

`JrmCoreEnergyAdapter` é um adaptador reflexivo experimental. Ele exige as
assinaturas exatas `getInt(EntityPlayer,String)` e
`setInt(EntityPlayer,String,int)`, cobra somente no servidor, arredonda o custo
para cima e verifica o valor após a escrita. Se a leitura posterior não confirmar
o valor esperado, tenta restaurar o valor anterior. A presença de `setInt` não
prova sozinha sua semântica; por isso a ponte só deve ser considerada homologada
depois de inspecionar o JAR exato e testar em jogo.

`TransformationEffectService` aplica modificadores vanilla de dano de ataque e
velocidade, usando UUIDs próprios para remover apenas os bônus do Dragon
Ascension. Esses atributos podem não controlar o cálculo de dano/atributos usado
por DBC. Integração com atributos internos do JRMCore, auras e partículas exige
validação adicional.
