#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SERVICE="$ROOT/src/main/java/com/dragonascension/core/TransformationSessionService.java"
EVENT="$ROOT/src/main/java/com/dragonascension/event/TransformationSyncEvents.java"
# Definite ACTIVE forms rejected for race/unlock reasons must clear the old
# session and return a completed reconciliation, allowing effects to refresh.
grep -F 'end(player, null);' "$SERVICE" >/dev/null
grep -A8 -F 'if (!data.isUnlocked(externalId) || raceKey == null' "$SERVICE" | grep -F 'return true;' >/dev/null
grep -F 'if (!synchronizedState) return;' "$EVENT" >/dev/null
grep -F 'refresh(player, activeId);' "$EVENT" >/dev/null
printf '%s\n' 'sync rejection cleanup: PASS'
