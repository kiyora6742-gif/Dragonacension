#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -source 8 -target 8 -d "$OUT" \
  "$ROOT"/verification/stubs/net/minecraft/nbt/*.java \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionDefinition.java" \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionRegistry.java" \
  "$ROOT/src/main/java/com/dragonascension/core/PlayerEvolutionData.java" \
  "$ROOT/verification/DisabledEvolutionPersistenceTest.java"
java -cp "$OUT" DisabledEvolutionPersistenceTest
