import com.dragonascension.compat.CompositeTransformationAdapter;
import com.dragonascension.compat.ITransformationAdapter;
import com.dragonascension.compat.TransformationReadResult;
import net.minecraft.entity.player.EntityPlayer;

public final class CompositeAdapterSmokeTest {
    private static final class Adapter implements ITransformationAdapter {
        private final TransformationReadResult result;
        Adapter(TransformationReadResult result) { this.result = result; }
        public String getId() { return "test"; }
        public boolean isAvailable() { return true; }
        public TransformationReadResult readTransformation(EntityPlayer player) { return result; }
    }
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        EntityPlayer player = new EntityPlayer();
        CompositeTransformationAdapter unknownAndInactive = new CompositeTransformationAdapter(
                new Adapter(TransformationReadResult.unknown()),
                new Adapter(TransformationReadResult.inactive()));
        require(unknownAndInactive.readTransformation(player).getStatus()
                == TransformationReadResult.Status.UNKNOWN,
                "falha de leitura não pode ser interpretada como estado normal");

        CompositeTransformationAdapter bothInactive = new CompositeTransformationAdapter(
                new Adapter(TransformationReadResult.inactive()),
                new Adapter(TransformationReadResult.inactive()));
        require(bothInactive.readTransformation(player).getStatus()
                == TransformationReadResult.Status.INACTIVE,
                "ambos os adaptadores confirmando inatividade devem encerrar a sessão");

        CompositeTransformationAdapter activeFallback = new CompositeTransformationAdapter(
                new Adapter(TransformationReadResult.unknown()),
                new Adapter(TransformationReadResult.active("saiyan.ssj")));
        require("saiyan.ssj".equals(activeFallback.readTransformation(player).getEvolutionId()),
                "forma ativa do adaptador secundário deve prevalecer");
        System.out.println("OK: adaptador composto preserva UNKNOWN e prioriza ACTIVE.");
    }
}
