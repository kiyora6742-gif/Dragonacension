#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
mkdir -p "$OUT/stubs/net/minecraft/entity/player" "$OUT/stubs/JinRyuu/JRMCore" "$OUT/test"
cat > "$OUT/stubs/net/minecraft/entity/player/EntityPlayer.java" <<'JAVA'
package net.minecraft.entity.player;
public class EntityPlayer { public World worldObj = new World(); public static class World { public boolean isRemote; } }
JAVA
cat > "$OUT/stubs/JinRyuu/JRMCore/JRMCoreH.java" <<'JAVA'
package JinRyuu.JRMCore;
import net.minecraft.entity.player.EntityPlayer;
public final class JRMCoreH {
 public static int energy = 20; public static boolean refuseWrite; public static boolean throwAfterWriteOnce;
 public static int getInt(EntityPlayer p, String key) { return energy; }
 public static void setInt(int value, EntityPlayer p, String key) {
  if (refuseWrite) return;
  energy = value;
  if (throwAfterWriteOnce) { throwAfterWriteOnce = false; throw new RuntimeException("simulated failure after mutation"); }
 }
}
JAVA
cat > "$OUT/test/EnergyAdapterTest.java" <<'JAVA'
import com.dragonascension.compat.JrmCoreEnergyAdapter;
import JinRyuu.JRMCore.JRMCoreH;
import net.minecraft.entity.player.EntityPlayer;
public class EnergyAdapterTest {
 public static void main(String[] args) {
  JrmCoreEnergyAdapter adapter = new JrmCoreEnergyAdapter();
  EntityPlayer player = new EntityPlayer();
  if (!adapter.isAvailable()) throw new AssertionError("API simulada deveria estar disponível");
  JRMCoreH.energy = 20;
  if (!adapter.consume(player, 4.2D) || JRMCoreH.energy != 15) throw new AssertionError("custo deve arredondar para cima");
  if (adapter.consume(player, 100D) || JRMCoreH.energy != 15) throw new AssertionError("não pode consumir sem saldo");
  player.worldObj.isRemote = true;
  if (adapter.consume(player, 1D) || JRMCoreH.energy != 15) throw new AssertionError("cliente não pode cobrar energia");
  player.worldObj.isRemote = false;
  JRMCoreH.refuseWrite = true;
  if (adapter.consume(player, 1D) || JRMCoreH.energy != 15) throw new AssertionError("falha de escrita deve ser recusada");
  JRMCoreH.throwAfterWriteOnce = true;
  if (adapter.consume(player, 2D) || JRMCoreH.energy != 15) throw new AssertionError("falha após mutação deve restaurar o saldo anterior");
  System.out.println("OK: consumo, arredondamento, saldo insuficiente, lado cliente, escrita não confirmada e rollback após exceção.");
 }
}
JAVA
javac -source 8 -target 8 -d "$OUT/classes" \
  $(find "$OUT/stubs" "$OUT/test" -name '*.java') \
  "$ROOT/src/main/java/com/dragonascension/compat/IPlayerEnergyAdapter.java" \
  "$ROOT/src/main/java/com/dragonascension/compat/JrmCoreEnergyAdapter.java"
java -cp "$OUT/classes" EnergyAdapterTest
