package JinRyuu.JRMCore;
import net.minecraft.entity.player.EntityPlayer;
public final class JRMCoreH {
    public static int energy = 100;
    public static boolean ignoreWrites;
    public static int getInt(EntityPlayer player, String key) { return energy; }
    public static void setInt(int value, EntityPlayer player, String key) { if (!ignoreWrites) energy = value; }
}
