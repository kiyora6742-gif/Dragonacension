package net.minecraft.nbt;
import java.util.ArrayList;
import java.util.List;
public class NBTTagList {
    private final List<Object> values = new ArrayList<Object>();
    public void appendTag(Object value) { values.add(value); }
    public int tagCount() { return values.size(); }
    public NBTTagCompound getCompoundTagAt(int i) { return (NBTTagCompound) values.get(i); }
    public String getStringTagAt(int i) { return ((NBTTagString) values.get(i)).getString(); }
}
