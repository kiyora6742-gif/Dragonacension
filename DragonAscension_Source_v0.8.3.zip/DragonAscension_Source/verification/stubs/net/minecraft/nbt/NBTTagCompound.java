package net.minecraft.nbt;
import java.util.HashMap;
import java.util.Map;
public class NBTTagCompound {
    private final Map<String,Object> values = new HashMap<String,Object>();
    public void setString(String k,String v) { values.put(k,v); }
    public String getString(String k) { Object v=values.get(k); return v instanceof String?(String)v:""; }
    public void setLong(String k,long v) { values.put(k,Long.valueOf(v)); }
    public long getLong(String k) { Object v=values.get(k); return v instanceof Number?((Number)v).longValue():0L; }
    public void setDouble(String k,double v) { values.put(k,Double.valueOf(v)); }
    public double getDouble(String k) { Object v=values.get(k); return v instanceof Number?((Number)v).doubleValue():0.0D; }
    public void setTag(String k,Object v) { values.put(k,v); }
    public boolean hasKey(String k) { return values.containsKey(k); }
    public NBTTagCompound getCompoundTag(String k) { Object v=values.get(k); return v instanceof NBTTagCompound?(NBTTagCompound)v:new NBTTagCompound(); }
    public NBTTagList getTagList(String k,int type) { Object v=values.get(k); return v instanceof NBTTagList?(NBTTagList)v:new NBTTagList(); }
}
