package net.minecraft.nbt;
public class NBTTagString {
    private final String value;
    public NBTTagString(String value) { this.value = value; }
    public String getString() { return value; }
}
