package net.minecraft.entity.player;
import net.minecraft.world.World;
public class EntityPlayer { public World worldObj = new World(); }
