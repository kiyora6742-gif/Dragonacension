#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
mkdir -p "$OUT/src/net/minecraft/entity/ai/attributes" "$OUT/src/net/minecraft/entity/player" "$OUT/src/net/minecraft/entity" "$OUT/classes"
cat > "$OUT/src/net/minecraft/entity/ai/attributes/IAttribute.java" <<'JAVA'
package net.minecraft.entity.ai.attributes;
public interface IAttribute {}
JAVA
cat > "$OUT/src/net/minecraft/entity/ai/attributes/AttributeModifier.java" <<'JAVA'
package net.minecraft.entity.ai.attributes;
import java.util.UUID;
public final class AttributeModifier {
 private final UUID id; private final String name; private final double amount; private final int operation;
 public AttributeModifier(UUID id,String name,double amount,int operation){this.id=id;this.name=name;this.amount=amount;this.operation=operation;}
 public UUID getID(){return id;} public double getAmount(){return amount;} public int getOperation(){return operation;} public String getName(){return name;}
}
JAVA
cat > "$OUT/src/net/minecraft/entity/ai/attributes/IAttributeInstance.java" <<'JAVA'
package net.minecraft.entity.ai.attributes;
import java.util.*;
public final class IAttributeInstance {
 private final Map<UUID,AttributeModifier> values=new HashMap<UUID,AttributeModifier>();
 public AttributeModifier getModifier(UUID id){return values.get(id);}
 public void removeModifier(AttributeModifier m){if(m!=null)values.remove(m.getID());}
 public void applyModifier(AttributeModifier m){values.put(m.getID(),m);}
 public int size(){return values.size();}
}
JAVA
cat > "$OUT/src/net/minecraft/entity/SharedMonsterAttributes.java" <<'JAVA'
package net.minecraft.entity;
import net.minecraft.entity.ai.attributes.IAttribute;
public final class SharedMonsterAttributes { public static final IAttribute attackDamage=new IAttribute(){}; public static final IAttribute movementSpeed=new IAttribute(){}; }
JAVA
cat > "$OUT/src/net/minecraft/entity/player/EntityPlayer.java" <<'JAVA'
package net.minecraft.entity.player;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
public final class EntityPlayer {
 public World worldObj=new World(); private final IAttributeInstance attack=new IAttributeInstance(), speed=new IAttributeInstance();
 public IAttributeInstance getEntityAttribute(IAttribute a){return a==SharedMonsterAttributes.attackDamage?attack:speed;}
 public IAttributeInstance attack(){return attack;} public IAttributeInstance speed(){return speed;}
 public static final class World { public boolean isRemote=false; }
}
JAVA
cat > "$OUT/src/EffectTest.java" <<'JAVA'
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import com.dragonascension.core.TransformationEffectService;
import java.util.UUID;
public final class EffectTest {
 public static void main(String[] args){
  EntityPlayer p=new EntityPlayer();
  com.dragonascension.core.EvolutionRegistry.registerBuiltInDefinitions();
  TransformationEffectService.refresh(p,"saiyan.ssj");
  if(p.attack().size()!=1 || p.speed().size()!=1) throw new AssertionError("SSJ modifiers not applied");
  TransformationEffectService.refresh(p,"saiyan.ssj4");
  if(p.attack().size()!=1 || p.speed().size()!=1) throw new AssertionError("refresh duplicated modifiers");
  AttributeModifier attack=p.attack().getModifier(UUID.fromString("3f47dcb2-92f1-4c89-9b61-4e0e3d1f1001"));
  AttributeModifier speed=p.speed().getModifier(UUID.fromString("3f47dcb2-92f1-4c89-9b61-4e0e3d1f1002"));
  if(attack==null || attack.getAmount()!=4.0D || speed==null || speed.getAmount()!=0.22D) throw new AssertionError("SSJ4 values incorrect");
  TransformationEffectService.refresh(p,"saiyan.not_a_real_form");
  if(p.attack().size()!=0 || p.speed().size()!=0) throw new AssertionError("unknown evolution retained or gained modifiers");
  TransformationEffectService.refresh(p,"saiyan.ssj4");
  if(p.attack().size()!=1 || p.speed().size()!=1) throw new AssertionError("valid form did not reapply after unknown id");
  TransformationEffectService.clear(p);
  if(p.attack().size()!=0 || p.speed().size()!=0) throw new AssertionError("clear did not remove owned modifiers");
  p.worldObj.isRemote=true; TransformationEffectService.refresh(p,"saiyan.ssj");
  if(p.attack().size()!=0 || p.speed().size()!=0) throw new AssertionError("client-side mutation was not blocked");
  System.out.println("OK: aplicação, substituição sem duplicação, valores SSJ4, rejeição de IDs desconhecidos, limpeza e bloqueio no cliente.");
 }
}
JAVA
javac -source 8 -target 8 -d "$OUT/classes" $(find "$OUT/src" -name '*.java') \
 "$ROOT/src/main/java/com/dragonascension/core/EvolutionDefinition.java" \
 "$ROOT/src/main/java/com/dragonascension/core/EvolutionRegistry.java" \
 "$ROOT/src/main/java/com/dragonascension/core/TransformationEffectService.java"
java -cp "$OUT/classes" EffectTest
