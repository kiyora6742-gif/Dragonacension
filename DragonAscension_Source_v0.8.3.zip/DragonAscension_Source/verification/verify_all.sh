#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
"$ROOT/verification/verify_registry.sh"
"$ROOT/verification/verify_energy_policy.sh"
"$ROOT/verification/verify_transformation_adapter.sh"
"$ROOT/verification/verify_race_guard.sh"
"$ROOT/verification/verify_v060_bridges.sh"

"$ROOT/verification/verify_energy_adapter_runtime.sh"
"$ROOT/verification/verify_sync_rejection_cleanup.sh"

"$ROOT/verification/verify_effect_service_runtime.sh"
"$ROOT/verification/verify_aura_service_runtime.sh"

"$ROOT/verification/verify_unknown_active_cleanup.sh"

"$ROOT/verification/verify_real_api_signatures.sh"
"$ROOT/verification/verify_mastery_race_guard.sh"
"$ROOT/verification/verify_build_scripts.sh"

"$ROOT/verification/verify_disabled_evolution_persistence.sh"
