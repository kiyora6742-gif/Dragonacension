import com.dragonascension.core.EvolutionDefinition;
import com.dragonascension.core.EvolutionRegistry;

public final class RegistrySmokeTest {
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        EvolutionRegistry.registerBuiltInDefinitions();
        require(EvolutionRegistry.all().size() == 38, "esperadas 38 evoluções, encontradas " + EvolutionRegistry.all().size());
        require(EvolutionRegistry.audit().isEmpty(), "árvore contém erros: " + EvolutionRegistry.audit());
        require(EvolutionRegistry.countByRace("saiyan") == 13, "quantidade Saiyajin incorreta");
        require(EvolutionRegistry.countByRace("half_saiyan") == 6, "quantidade Meio-Saiyajin incorreta");
        require(EvolutionRegistry.countByRace("arcosian") == 7, "quantidade Arcosiana incorreta");
        require(EvolutionRegistry.countByRace("namekian") == 4, "quantidade Namekuseijin incorreta");
        require(EvolutionRegistry.countByRace("human") == 4, "quantidade Humana incorreta");
        require(EvolutionRegistry.countByRace("majin") == 4, "quantidade Majin incorreta");

        EvolutionDefinition golden = EvolutionRegistry.get("saiyan.golden_oozaru");
        EvolutionDefinition ssj4 = EvolutionRegistry.get("saiyan.ssj4");
        EvolutionDefinition uiSign = EvolutionRegistry.get("saiyan.ultra_instinct_sign");
        EvolutionDefinition ui = EvolutionRegistry.get("saiyan.ultra_instinct");
        require(golden != null && "saiyan.ozaru".equals(golden.getParentId()), "Oozaru Dourado deve depender de Oozaru");
        require(ssj4 != null && "saiyan.golden_oozaru".equals(ssj4.getParentId()), "SSJ4 deve depender de Oozaru Dourado");
        require(uiSign != null && uiSign.getParentId() == null, "Instinto Superior Sinal deve ser ramificação independente");
        require(ui != null && "saiyan.ultra_instinct_sign".equals(ui.getParentId()), "Instinto Superior deve depender do Sinal");

        EvolutionDefinition black = EvolutionRegistry.get("arcosian.black");
        require(black != null && "arcosian".equals(black.getRaceKey()), "Black Freeza deve ser exclusivo Arcosiano");
        for (EvolutionDefinition definition : EvolutionRegistry.all()) {
            if (definition.getParentId() != null) {
                EvolutionDefinition parent = EvolutionRegistry.get(definition.getParentId());
                require(parent != null, "pré-requisito ausente para " + definition.getId());
                require(definition.getRaceKey().equals(parent.getRaceKey()), "raças divergentes em " + definition.getId());
            }
        }
        System.out.println("OK: 38 evoluções; 6 árvores; pré-requisitos, ramificações Saiyajin e exclusividade Arcosiana validados.");
    }
}
