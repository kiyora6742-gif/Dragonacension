import com.dragonascension.core.EvolutionDefinition;
import com.dragonascension.core.EvolutionRegistry;
import com.dragonascension.core.PlayerEvolutionData;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;

public final class DisabledEvolutionPersistenceTest {
    public static void main(String[] args) {
        EvolutionRegistry.registerBuiltInDefinitions();
        EvolutionRegistry.register(new EvolutionDefinition("saiyan.retired", "Retired", "saiyan",
                null, 0, 0.0D, false, false, false));

        NBTTagCompound root = new NBTTagCompound();
        NBTTagCompound saved = new NBTTagCompound();
        saved.setString("RaceKey", "saiyan");
        saved.setString("ActiveTransformationId", "saiyan.retired");
        NBTTagList unlocked = new NBTTagList();
        unlocked.appendTag(new NBTTagString("saiyan.ssj"));
        unlocked.appendTag(new NBTTagString("saiyan.retired"));
        saved.setTag("Unlocked", unlocked);
        NBTTagList training = new NBTTagList();
        training.appendTag(new NBTTagString("saiyan.retired"));
        saved.setTag("Training", training);
        NBTTagList challenges = new NBTTagList();
        challenges.appendTag(new NBTTagString("saiyan.retired"));
        saved.setTag("Challenges", challenges);
        NBTTagList mastery = new NBTTagList();
        NBTTagCompound retiredMastery = new NBTTagCompound();
        retiredMastery.setString("Id", "saiyan.retired");
        retiredMastery.setDouble("Value", 99.0D);
        mastery.appendTag(retiredMastery);
        saved.setTag("Mastery", mastery);
        root.setTag("DragonAscension", saved);

        PlayerEvolutionData data = new PlayerEvolutionData();
        data.readFromNBT(root);
        if (!data.isUnlocked("saiyan.ssj")) throw new AssertionError("enabled evolution lost");
        if (data.isUnlocked("saiyan.retired")) throw new AssertionError("disabled evolution restored");
        if (data.getMastery("saiyan.retired") != 0.0D) throw new AssertionError("disabled mastery restored");
        if (data.hasTraining("saiyan.retired") || data.hasChallenge("saiyan.retired"))
            throw new AssertionError("disabled progression restored");
        if (data.getActiveTransformationId().length() != 0) throw new AssertionError("disabled active session restored");
        System.out.println("OK: evolucoes desativadas nao recuperam desbloqueios, dominio, progresso ou sessao ativa.");
    }
}
