#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
javac -d "$OUT" \
  "$ROOT/src/main/java/com/dragonascension/core/TransformationEnergyPolicy.java" \
  "$ROOT/verification/EnergyPolicySmokeTest.java"
java -cp "$OUT" EnergyPolicySmokeTest
