#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
mkdir -p "$OUT/src/net/minecraft/entity/player" "$OUT/classes"
cat > "$OUT/src/net/minecraft/entity/player/EntityPlayer.java" <<'JAVA'
package net.minecraft.entity.player;
import java.util.ArrayList; import java.util.List;
public final class EntityPlayer {
 public World worldObj=new World(); public int ticksExisted=10; public double posX=0,posY=64,posZ=0;
 public static class World { public boolean isRemote=false; public final List<String> particles=new ArrayList<String>(); public void func_147487_a(String p,double x,double y,double z,int count,double ox,double oy,double oz,double speed){particles.add(p+":"+count);} }
 public static final class McpWorld extends World { public void spawnParticle(String p,double x,double y,double z,int count,double ox,double oy,double oz,double speed){particles.add(p+":"+count);} }
}
JAVA
cat > "$OUT/src/AuraTest.java" <<'JAVA'
import net.minecraft.entity.player.EntityPlayer;
import com.dragonascension.core.TransformationAuraService;
public final class AuraTest { public static void main(String[] a) {
 EntityPlayer p=new EntityPlayer();
 TransformationAuraService.emit(p,"saiyan.ultra_instinct");
 if(p.worldObj.particles.size()!=1 || !"witchMagic:1".equals(p.worldObj.particles.get(0))) throw new AssertionError("UI aura");
 TransformationAuraService.emit(p,"saiyan.golden_oozaru");
 if(!"reddust:1".equals(p.worldObj.particles.get(1))) throw new AssertionError("gold aura");
 TransformationAuraService.emit(p,null);
 p.worldObj.isRemote=true; TransformationAuraService.emit(p,"saiyan.ssj");
 if(p.worldObj.particles.size()!=2) throw new AssertionError("invalid state/client should not emit");
 EntityPlayer.McpWorld mcp = new EntityPlayer.McpWorld();
 EntityPlayer q = new EntityPlayer();
 try { EntityPlayer.class.getField("worldObj").set(q, mcp); }
 catch (Exception e) { throw new AssertionError(e); }
 if (!TransformationAuraService.emit(q,"saiyan.ssj") || mcp.particles.size()!=1 || !"crit:1".equals(mcp.particles.get(0))) throw new AssertionError("MCP spawnParticle fallback");
 System.out.println("OK: broadcast WorldServer 1.7.10 por nome SRG/MCP, seleção de partículas, estado vazio e bloqueio no cliente.");
} }
JAVA
javac -source 8 -target 8 -d "$OUT/classes" $(find "$OUT/src" -name '*.java') "$ROOT/src/main/java/com/dragonascension/core/TransformationAuraService.java"
java -cp "$OUT/classes" AuraTest
