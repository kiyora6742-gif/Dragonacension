import com.dragonascension.core.EvolutionDefinition;
import com.dragonascension.core.EvolutionRegistry;
import com.dragonascension.core.PlayerEvolutionData;

public final class MasteryRaceGuardTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        EvolutionRegistry.registerBuiltInDefinitions();
        PlayerEvolutionData data = new PlayerEvolutionData();
        data.setRaceKey("saiyan");
        data.setMastery("unknown.form", 90.0D);
        check(data.getMastery("unknown.form") == 0.0D, "unknown ID must be rejected");
        data.setMastery("arcosian.black", 90.0D);
        check(data.getMastery("arcosian.black") == 0.0D, "foreign race mastery must be rejected");
        data.setMastery("saiyan.ssj", 150.0D);
        check(data.getMastery("saiyan.ssj") == 100.0D, "valid mastery must remain capped");
        data.setRaceKey("arcosian");
        check(data.getMastery("saiyan.ssj") == 0.0D, "race change must prune old mastery");
        data.setMastery("arcosian.black", 42.5D);
        check(data.getMastery("arcosian.black") == 42.5D, "current-race mastery must be accepted");
        System.out.println("OK: domínio rejeita IDs desconhecidos e evoluções de outra raça; troca racial limpa domínio antigo.");
    }
}
