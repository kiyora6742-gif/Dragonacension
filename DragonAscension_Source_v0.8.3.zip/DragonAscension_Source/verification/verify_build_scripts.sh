#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
for file in "$ROOT/BUILD_WINDOWS.bat" "$ROOT/build-linux.sh" "$ROOT/BUILDING.md"; do
  test -s "$file"
done
grep -F 'JAVA_HOME' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F 'javac.exe' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F 'JAVA_HOME' "$ROOT/build-linux.sh" >/dev/null
grep -F 'javac' "$ROOT/build-linux.sh" >/dev/null
grep -F 'PROJECT_VERSION' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F 'tokens=2 delims== ' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F 'PROJECT_VERSION' "$ROOT/build-linux.sh" >/dev/null
grep -F 'EXPECTED_JAR' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F 'EXPECTED_JAR' "$ROOT/build-linux.sh" >/dev/null
grep -F 'Gradle 6.9.1' "$ROOT/BUILDING.md" >/dev/null
grep -F '6.9.1' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F "= '6.9.1'" "$ROOT/build-linux.sh" >/dev/null
! grep -F "= '2.14.1'" "$ROOT/build-linux.sh" >/dev/null
grep -F 'com.github.GTNewHorizons:ForgeGradle:1.2.11' "$ROOT/build.gradle" >/dev/null
grep -F 'https://jitpack.io' "$ROOT/build.gradle" >/dev/null
! grep -F "exclude group: 'org.eclipse.equinox'" "$ROOT/build.gradle" >/dev/null
grep -F 'gradle --no-daemon help --stacktrace' "$ROOT/build-linux.sh" >/dev/null
grep -F 'gradle --no-daemon help --stacktrace' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
echo 'OK: scripts exigem JDK 8, Gradle 6.9.1, fazem preflight do Gradle e derivam o JAR do build.gradle.'

grep -F 'GRADLE_JVM' "$ROOT/BUILD_WINDOWS.bat" >/dev/null
grep -F 'GRADLE_JVM' "$ROOT/build-linux.sh" >/dev/null
grep -F 'o Gradle nao esta executando com Java 8' "$ROOT/build-linux.sh" >/dev/null
