import JinRyuu.JRMCore.JRMCoreH;
import com.dragonascension.compat.JrmCoreEnergyAdapter;
import net.minecraft.entity.player.EntityPlayer;

/** Isolated reflection-contract test; does not prove compatibility with a real JRMCore build. */
public final class JrmCoreEnergyAdapterSmokeTest {
    public static void main(String[] args) {
        JrmCoreEnergyAdapter adapter = new JrmCoreEnergyAdapter();
        EntityPlayer player = new EntityPlayer();
        require(adapter.isAvailable(), "fake JRMCore API should be discovered");

        JRMCoreH.energy = 100;
        require(adapter.consume(player, 10.2D), "valid charge should succeed");
        require(JRMCoreH.energy == 89, "charge must round up and subtract");

        JRMCoreH.energy = 5;
        require(!adapter.consume(player, 6.0D), "insufficient energy must fail");
        require(JRMCoreH.energy == 5, "insufficient energy must not mutate balance");

        JRMCoreH.energy = 50;
        JRMCoreH.ignoreWrites = true;
        require(!adapter.consume(player, 10.0D), "unverified write must fail");
        require(JRMCoreH.energy == 50, "failed write must leave balance unchanged");
        JRMCoreH.ignoreWrites = false;

        player.worldObj.isRemote = true;
        require(!adapter.consume(player, 1.0D), "client-side charge must fail");
        System.out.println("JrmCoreEnergyAdapterSmokeTest: PASS (4 cases)");
    }
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
