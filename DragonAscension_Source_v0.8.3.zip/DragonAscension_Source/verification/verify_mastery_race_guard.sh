#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
javac -source 8 -target 8 -d "$OUT" \
  "$ROOT"/verification/stubs/net/minecraft/nbt/*.java \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionDefinition.java" \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionRegistry.java" \
  "$ROOT/src/main/java/com/dragonascension/core/PlayerEvolutionData.java" \
  "$ROOT/verification/MasteryRaceGuardTest.java"
java -cp "$OUT" MasteryRaceGuardTest
