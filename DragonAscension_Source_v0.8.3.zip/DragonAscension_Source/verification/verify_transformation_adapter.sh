#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/dragon-ascension-adapter-test-$$
trap 'rm -rf "$TMP"' EXIT HUP INT TERM
mkdir -p "$TMP/src/net/minecraft/entity/player" "$TMP/classes"
cat > "$TMP/src/net/minecraft/entity/player/EntityPlayer.java" <<'JAVA'
package net.minecraft.entity.player;
public class EntityPlayer {
    public World worldObj;
    public static class World { public boolean isRemote; }
}
JAVA
javac -source 8 -target 8 -d "$TMP/classes" \
  "$TMP/src/net/minecraft/entity/player/EntityPlayer.java" \
  "$ROOT/src/main/java/com/dragonascension/compat/TransformationReadResult.java" \
  "$ROOT/src/main/java/com/dragonascension/compat/ITransformationAdapter.java" \
  "$ROOT/src/main/java/com/dragonascension/compat/CompositeTransformationAdapter.java" \
  "$ROOT/verification/TransformationReadResultSmokeTest.java" \
  "$ROOT/verification/CompositeAdapterSmokeTest.java"
java -cp "$TMP/classes" TransformationReadResultSmokeTest
java -cp "$TMP/classes" CompositeAdapterSmokeTest
# Compile both reflection-only adapters against the same minimal Minecraft player stub.
javac -source 8 -target 8 -cp "$TMP/classes" -d "$TMP/classes" \
  "$ROOT/src/main/java/com/dragonascension/compat/DbcAdditionsTransformationAdapter.java" \
  "$ROOT/src/main/java/com/dragonascension/compat/DbcNativeTransformationAdapter.java"
echo "OK: adaptadores reflexivos compilam contra o contrato tri-state."
