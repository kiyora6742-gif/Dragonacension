#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
javac -d "$OUT" \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionDefinition.java" \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionRegistry.java" \
  "$ROOT/verification/RegistrySmokeTest.java"
java -cp "$OUT" RegistrySmokeTest
