#!/bin/sh
set -eu
JRM=${JRMCORE_JAR:-/mnt/data/JRMCore-v1.3.51.jar}
ADDITIONS=${DBCADD_JAR:-/mnt/data/DBCAdditions-1.8.10.jar}
test -f "$JRM" && test -f "$ADDITIONS"
JRM_OUT=$(javap -classpath "$JRM" -p -s JinRyuu.JRMCore.JRMCoreH)
printf '%s' "$JRM_OUT" | grep -F 'setInt(int, net.minecraft.entity.player.EntityPlayer, java.lang.String)' >/dev/null
printf '%s' "$JRM_OUT" | grep -F 'getInt(net.minecraft.entity.player.EntityPlayer, java.lang.String)' >/dev/null
printf '%s' "$JRM_OUT" | grep -F 'getByte(net.minecraft.entity.player.EntityPlayer, java.lang.String)' >/dev/null
printf '%s' "$JRM_OUT" | grep -F 'getTransformationName(int, int, boolean, boolean, boolean, boolean)' >/dev/null
ADD_OUT=$(javap -classpath "$ADDITIONS" -p com.ximen.dbcadditions.data.DBCAPlayer)
printf '%s' "$ADD_OUT" | grep -F 'public static com.ximen.dbcadditions.data.DBCAPlayer get(net.minecraft.entity.player.EntityPlayer)' >/dev/null
printf '%s' "$ADD_OUT" | grep -F 'public int DBAForm' >/dev/null
printf '%s' "$ADD_OUT" | grep -F 'public byte getRace()' >/dev/null
FORM_OUT=$(javap -classpath "$ADDITIONS" -p com.ximen.dbcadditions.data.forms.DBCAForms)
printf '%s' "$FORM_OUT" | grep -F 'getForm(int)' >/dev/null
printf '%s' "$FORM_OUT" >/dev/null
FORM_OUT=$(javap -classpath "$ADDITIONS" -p com.ximen.dbcadditions.data.forms.DBCAForm)
printf '%s' "$FORM_OUT" | grep -F 'getName()' >/dev/null
printf '%s\n' 'OK: assinaturas públicas conferidas nos JARs reais JRMCore 1.3.51 e DBC Additions 1.8.10.'
