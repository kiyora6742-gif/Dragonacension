#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT HUP INT TERM
mkdir -p "$OUT/stubs/net/minecraft/entity/player" "$OUT/stubs/net/minecraft/entity/ai/attributes" "$OUT/stubs/net/minecraft/entity"
cat > "$OUT/stubs/net/minecraft/entity/player/EntityPlayer.java" <<'JAVA'
package net.minecraft.entity.player;
public class EntityPlayer { public World worldObj; public static class World { public boolean isRemote; } }
JAVA
cat > "$OUT/stubs/net/minecraft/entity/SharedMonsterAttributes.java" <<'JAVA'
package net.minecraft.entity;
import net.minecraft.entity.ai.attributes.IAttribute;
public final class SharedMonsterAttributes {
 public static final IAttribute attackDamage = new IAttribute(){};
 public static final IAttribute movementSpeed = new IAttribute(){};
}
JAVA
cat > "$OUT/stubs/net/minecraft/entity/ai/attributes/IAttribute.java" <<'JAVA'
package net.minecraft.entity.ai.attributes;
public interface IAttribute {}
JAVA
cat > "$OUT/stubs/net/minecraft/entity/ai/attributes/AttributeModifier.java" <<'JAVA'
package net.minecraft.entity.ai.attributes;
import java.util.UUID;
public class AttributeModifier {
 public AttributeModifier(UUID id, String name, double amount, int operation) {}
}
JAVA
cat > "$OUT/stubs/net/minecraft/entity/ai/attributes/IAttributeInstance.java" <<'JAVA'
package net.minecraft.entity.ai.attributes;
import java.util.UUID;
public interface IAttributeInstance {
 AttributeModifier getModifier(UUID id);
 void removeModifier(AttributeModifier modifier);
 void applyModifier(AttributeModifier modifier);
}
JAVA
cat > "$OUT/stubs/net/minecraft/entity/player/EntityPlayer.java.tmp" <<'EOF2'
EOF2
# Add the attribute lookup method to the player stub.
python3 - "$OUT/stubs/net/minecraft/entity/player/EntityPlayer.java" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
s=s.replace('public static class World', 'public net.minecraft.entity.ai.attributes.IAttributeInstance getEntityAttribute(net.minecraft.entity.ai.attributes.IAttribute a) { return null; } public static class World')
p.write_text(s)
PY
javac -source 8 -target 8 -d "$OUT/classes" \
  $(find "$OUT/stubs" -name '*.java' ! -name '*.tmp') \
  "$ROOT/src/main/java/com/dragonascension/compat/IPlayerEnergyAdapter.java" \
  "$ROOT/src/main/java/com/dragonascension/compat/JrmCoreEnergyAdapter.java" \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionDefinition.java" \
  "$ROOT/src/main/java/com/dragonascension/core/EvolutionRegistry.java" \
  "$ROOT/src/main/java/com/dragonascension/core/TransformationEffectService.java"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
main=(root/'src/main/java/com/dragonascension/DragonAscension.java').read_text()
event=(root/'src/main/java/com/dragonascension/event/TransformationSyncEvents.java').read_text()
energy=(root/'src/main/java/com/dragonascension/compat/JrmCoreEnergyAdapter.java').read_text()
effects=(root/'src/main/java/com/dragonascension/core/TransformationEffectService.java').read_text()
assert 'new JrmCoreEnergyAdapter()' in main and 'energyAdapter.isAvailable()' in main
assert 'getMethod("setInt", Integer.TYPE, EntityPlayer.class, String.class)' in energy
assert 'bridge.getInt.invoke(null, player, ENERGY_KEY)' in energy and 'after == expected' in energy
assert 'TransformationEffectService.refresh(player, activeId)' in event
assert 'removeOwned(attack, ATTACK_UUID)' in effects and 'removeOwned(speed, SPEED_UUID)' in effects
print('OK: ponte de energia fail-closed, leitura de retorno e modificadores próprios compilam contra stubs.')
PY
