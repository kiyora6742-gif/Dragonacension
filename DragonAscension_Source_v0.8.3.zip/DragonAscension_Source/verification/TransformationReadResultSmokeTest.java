import com.dragonascension.compat.TransformationReadResult;

public final class TransformationReadResultSmokeTest {
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        require(TransformationReadResult.unknown().getStatus() == TransformationReadResult.Status.UNKNOWN,
                "falha de leitura deve permanecer UNKNOWN");
        require(TransformationReadResult.inactive().getStatus() == TransformationReadResult.Status.INACTIVE,
                "estado normal confirmado deve ser INACTIVE");
        TransformationReadResult active = TransformationReadResult.active("saiyan.ssj");
        require(active.getStatus() == TransformationReadResult.Status.ACTIVE,
                "forma mapeada deve ser ACTIVE");
        require("saiyan.ssj".equals(active.getEvolutionId()), "ID ativo incorreto");
        require(TransformationReadResult.active(" ").getStatus() == TransformationReadResult.Status.UNKNOWN,
                "ID vazio não pode virar forma ativa");
        System.out.println("OK: estados ACTIVE/INACTIVE/UNKNOWN diferenciados.");
    }
}
