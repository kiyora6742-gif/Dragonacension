import com.dragonascension.core.TransformationEnergyPolicy;

public final class EnergyPolicySmokeTest {
    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        double novice = TransformationEnergyPolicy.costForTicks(20, 0.0D);
        double expert = TransformationEnergyPolicy.costForTicks(20, 100.0D);
        require(novice == 20.0D, "custo base inesperado: " + novice);
        require(expert == 10.0D, "domínio máximo deve reduzir o custo em 50%: " + expert);
        require(TransformationEnergyPolicy.costForTicks(0, 50.0D) == 0.0D,
                "intervalo zero deve custar zero");
        require(TransformationEnergyPolicy.costForTicks(-5, 50.0D) == 0.0D,
                "intervalo negativo deve custar zero");
        require(TransformationEnergyPolicy.costForTicks(10, Double.NaN) == 0.0D,
                "domínio inválido deve custar zero");
        require(TransformationEnergyPolicy.costForTicks(10, 150.0D) == 5.0D,
                "domínio deve ser limitado a 100");
        System.out.println("OK: custo de energia por tick, desconto por domínio e entradas inválidas.");
    }
}
