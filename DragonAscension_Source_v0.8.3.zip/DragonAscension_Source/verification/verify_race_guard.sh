#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
root = Path(sys.argv[1])
unlock = (root / "src/main/java/com/dragonascension/core/EvolutionUnlockService.java").read_text()
session = (root / "src/main/java/com/dragonascension/core/TransformationSessionService.java").read_text()
assert "getVerifiedRaceKey(player, data)" in unlock
assert unlock.index("if (!definition.getRaceKey().equals(raceKey))") < unlock.index("if (data.isUnlocked(evolutionId))")
assert "if (raceKey == null || !definition.getRaceKey().equals(raceKey)) return false;" in session
assert "if (raceKey == null || !definition.getRaceKey().equals(raceKey)) {" in session
assert "if (!data.isUnlocked(externalId) || raceKey == null" in session
assert "end(player, evolutionId);" in session
assert "if (!IntegrationManager.hasPlayerContextAdapter()) return null;" in unlock
print("OK: desbloqueios, sincronização e domínio exigem raça atual verificada.")
PY
