#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SERVICE="$ROOT/src/main/java/com/dragonascension/core/TransformationSessionService.java"
EVENT="$ROOT/src/main/java/com/dragonascension/event/TransformationSyncEvents.java"
grep -A9 -F 'EvolutionDefinition definition = EvolutionRegistry.get(externalId);' "$SERVICE" | grep -F 'if (definition == null)' >/dev/null
grep -A9 -F 'EvolutionDefinition definition = EvolutionRegistry.get(externalId);' "$SERVICE" | grep -F 'end(player, null);' >/dev/null
grep -A9 -F 'EvolutionDefinition definition = EvolutionRegistry.get(externalId);' "$SERVICE" | grep -F 'return true;' >/dev/null
grep -F 'if (!synchronizedState) return;' "$EVENT" >/dev/null
grep -F 'refresh(player, activeId);' "$EVENT" >/dev/null
printf '%s\n' 'unknown ACTIVE cleanup: PASS'
