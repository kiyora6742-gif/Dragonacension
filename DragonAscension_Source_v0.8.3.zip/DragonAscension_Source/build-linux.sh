#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

fail() { echo "ERRO: $1" >&2; exit 1; }
[ -n "${JAVA_HOME:-}" ] || fail 'JAVA_HOME nao esta definido; aponte para um JDK 8.'
[ -x "$JAVA_HOME/bin/java" ] || fail 'java nao encontrado em JAVA_HOME.'
[ -x "$JAVA_HOME/bin/javac" ] || fail 'javac nao encontrado: e necessario JDK, nao apenas JRE.'
export JAVA_HOME
export PATH="$JAVA_HOME/bin:$PATH"
command -v gradle >/dev/null 2>&1 || fail 'Gradle nao encontrado no PATH; instale Gradle 6.9.1.'

JAVA_VERSION=$("$JAVA_HOME/bin/java" -version 2>&1 | sed -n '1s/.*version "\([^"]*\)".*/\1/p')
GRADLE_INFO=$(gradle --version)
GRADLE_VERSION=$(printf '%s\n' "$GRADLE_INFO" | sed -n 's/^Gradle //p' | head -n 1)
GRADLE_JVM=$(printf '%s\n' "$GRADLE_INFO" | sed -n 's/^JVM: //p' | head -n 1)
PROJECT_VERSION=$(sed -n 's/^[[:space:]]*version[[:space:]]*=[[:space:]]*\"\([^\"]*\)\".*/\1/p' build.gradle | head -n 1)
[ -n "$PROJECT_VERSION" ] || fail 'nao foi possivel ler a versao do build.gradle.'
EXPECTED_JAR="build/libs/DragonAscension-${PROJECT_VERSION}.jar"
printf 'Java detectado: %s\n' "$JAVA_VERSION"
"$JAVA_HOME/bin/javac" -version
printf 'Gradle detectado: %s (JVM: %s)\n' "$GRADLE_VERSION" "${GRADLE_JVM:-desconhecida}"
case "$JAVA_VERSION" in 1.8*) ;; *) fail 'esta compilacao exige JDK 8.';; esac
[ "$GRADLE_VERSION" = '6.9.1' ] || fail 'esta configuracao espera Gradle 6.9.1.'
case "$GRADLE_JVM" in 1.8*) ;; *) fail 'o Gradle nao esta executando com Java 8; confira JAVA_HOME e o ambiente do Gradle.';; esac
echo '[0/3] Validando a configuracao do projeto...'
gradle --no-daemon help --stacktrace
echo '[1/3] Preparando workspace Forge 1.7.10...'
gradle --no-daemon setupDecompWorkspace --stacktrace
echo '[2/3] Compilando Dragon Ascension...'
gradle --no-daemon clean build --stacktrace
[ -f "$EXPECTED_JAR" ] || fail "build terminou sem gerar $EXPECTED_JAR."
echo 'Build concluido:'
ls -lh "$EXPECTED_JAR"
