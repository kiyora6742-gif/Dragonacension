# Dragon Ascension — fonte v0.8.1

Versão do projeto: 0.8.1.

**Preparação de build:** scripts Windows/Linux agora validam `JAVA_HOME`, `javac`, Java 8 e Gradle 2.14.1; só confirmam sucesso se o JAR esperado existir. Guia em `BUILDING.md`.

**Limitação desta sessão:** só há Java 21; JDK 8 e Gradle 2.14.1 não estão instalados, e a resolução DNS externa falhou. Não foi possível baixar as ferramentas ou executar ForgeGradle. Esta entrega continua sendo código-fonte, não JAR instalável.

**Alvo:** Minecraft 1.7.10 / Forge 10.13.4.1614 / Java 7+.
**Build legado esperado:** JDK 8 + Gradle 2.14.1 + ForgeGradle 1.2.

## Estado atual da versão 0.8.1
- `PlayerEvolutionData.setMastery` agora aceita domínio apenas para IDs registrados que pertençam à raça interna atual. IDs desconhecidos e evoluções de outra raça são ignorados; a troca de raça continua removendo o domínio da raça anterior.
- As assinaturas de `getInt(EntityPlayer,String)`, `setInt(int,EntityPlayer,String)`, `getByte(EntityPlayer,String)` e `getTransformationName(int,int,boolean,boolean,boolean,boolean)` foram conferidas no JRMCore 1.3.51 fornecido.
- As assinaturas de entrada de `DBCAPlayer`, campo `DBAForm`, `getRace()`, `DBCAForms.getForm(int)` e `DBCAForm.getName()` foram conferidas no DBC Additions 1.8.10 fornecido.
- `verification/verify_real_api_signatures.sh` automatiza essas conferências usando os JARs originais. Isso confirma assinaturas públicas, não garante que a leitura de estados ou o consumo de energia funcionem em partida real.
- `verification/verify_mastery_race_guard.sh` cobre domínio de ID inexistente, domínio de raça estrangeira, limite máximo e limpeza após troca racial.

**Limitações atuais:** ainda não foi executado o build completo ForgeGradle nem um teste dentro do Minecraft 1.7.10. O ambiente atual tem Java 21 e não tem uma instalação utilizável do Gradle legado; o build esperado continua sendo JDK 8 + Gradle 2.14.1 + ForgeGradle 1.2. Esta entrega é código-fonte, não JAR instalável.

---



## O que esta versão contém
- Bootstrap Forge e proxies.
- Registro de 38 definições internas de evolução para Saiyajin, Meio-Saiyajin,
  Arcosiano, Namekuseijin, Humano e Majin.
- Encadeamento por pré-requisitos e validação de raça, nível, domínio, treino e desafio.
- Evoluções encadeadas verificam o domínio da forma anterior.
- Dados persistidos em NBT separado (`EntityPlayer.PERSISTED_NBT_TAG`) e cópia no clone.
- Auditoria estrutural da árvore (pais ausentes, raça divergente e ciclos).
- Comando `compat` que informa quais adaptadores ainda não foram implementados.
- Validação explícita de nível desconhecido: `null` não é tratado como nível zero.

## Comandos
- `/dragonascension list`
- `/dragonascension info <id-evolução>`
- `/dragonascension audit`
- `/dragonascension compat`
- `/dragonascension status <jogador>`
- `/dragonascension setrace <jogador> <raça>`
- `/dragonascension mastery <jogador> <evolução> <0-100>`
- `/dragonascension training <jogador> <evolução>`
- `/dragonascension challenge <jogador> <evolução>`
- `/dragonascension unlock <jogador> <evolução>`

Todas as operações administrativas exigem OP nível 2.

## Limitações importantes
Esta entrega é **código-fonte**, não um JAR instalável.

1. As chaves `saiyan`, `half_saiyan`, `arcosian`, `namekian`, `human` e `majin`
   são chaves internas provisórias, não IDs oficiais do DBC.
2. `setrace` continua sendo uma ferramenta administrativa de desenvolvimento.
3. O nível real do jogador ainda não é lido do JRMCore. Por isso, `unlock` bloqueia
   evoluções com requisito de nível positivo e informa que o nível não pode ser verificado.
4. Treinamento e desafio são flags administrativas, não missões ou mecânicas jogáveis.
5. As 38 definições são uma proposta de progressão; não provam que todas as formas existam
   nos mods instalados nem criam transformações no DBC.
6. Ainda não existem adaptadores reais para transformação/energia do DBC, raça/nível/atributos
   do JRMCore ou formas/mastery do DBC Additions. O comando `compat` deixa isso explícito.
7. Não há ainda cálculo de custos/multiplicadores, sincronização de rede própria ou interface.

## Build
Com JDK 8 e Gradle 2.14.1:

    gradle setupDecompWorkspace
    gradle build

O artefato deverá aparecer em `build/libs/` se o ambiente legado compilar corretamente.

## Estado de validação desta entrega
- Verificação de estrutura do ZIP e inspeção do código-fonte realizadas.
- Verificações desta revisão estão registradas em `VERIFICACOES_v0.1.6.txt`.
- Build ForgeGradle completo e teste dentro do Minecraft **não foram realizados** neste ambiente.


## Histórico de versões anteriores (notas preservadas)

As seções abaixo registram decisões e limitações de versões antigas; quando divergirem do estado atual, prevalece a seção “Estado atual da versão 0.8.1”.

## Compatibilidade — v0.1.6

Esta versão adiciona uma camada neutra de integração em `compat/`:

- `IPlayerContextAdapter`: contrato para um adaptador verificado fornecer raça canônica, nível e energia do jogador.
- `PlayerContext`: snapshot imutável com valores opcionais (ausentes permanecem desconhecidos).
- `IntegrationManager`: ponto único de registro/leitura do adaptador, sem importar classes do DBC/JRMCore.
- `/dragonascension compat`: mostra detecção heurística dos mods e se um adaptador foi registrado.
- `/dragonascension context [jogador]`: mostra os dados fornecidos pelo adaptador, ou informa que ainda não há provedor.

O desbloqueio passa a usar raça e nível do adaptador quando disponível; sem adaptador, mantém a raça interna definida administrativamente e trata o nível como desconhecido. A presença de um mod no Forge **não** prova compatibilidade da API. Ainda não há adaptador concreto implementado, pois os métodos/IDs precisam ser confirmados contra os JARs exatos.

### Limites desta versão

Ainda não implementados: chamadas reais de transformação/descida, leitura real de atributos e energia, custo e multiplicadores, integração de mastery do DBC Additions, packets/sincronização, UI e efeitos visuais. Este ZIP é código-fonte; não é um JAR pronto para instalar.


## Robustez de integração — v0.1.6

- `PlayerContext` normaliza a chave de raça e descarta nível negativo, energia negativa, NaN ou infinito.
- `IntegrationManager` protege chamadas a adaptadores opcionais contra `RuntimeException` e `LinkageError`, evitando que uma API ausente derrube o mod-base.
- O registro do adaptador é publicado com segurança entre threads.
- Se um adaptador estiver registrado, mas indisponível ou sem raça verificável, `unlock` falha de forma segura em vez de recorrer à raça administrativa provisória.
- Sem adaptador, a raça interna continua disponível apenas como mecanismo temporário de desenvolvimento; nível permanece desconhecido.

Nenhuma API concreta do DBC/JRMCore foi presumida. A implementação real do adaptador ainda depende de validar os JARs exatos e os IDs/métodos da versão instalada.


## Novidades da v0.1.7

- `EvolutionRegistry.byRace`, `childrenOf` e `countByRace` permitem consultar a árvore
  por raça interna sem expor a coleção mutável do registro.
- Novo comando `/dragonascension tree <raça>` lista as evoluções da raça, seus pais,
  domínio exigido, nível, treino e desafio.
- Normalização de subcomandos e chaves de raça usa `Locale.ROOT`, evitando diferenças
  de idioma/região no servidor.
- Os pontos de leitura/salvamento NBT e o evento de cópia agora ignoram argumentos nulos
  com segurança.
- A versão do mod e do artefato Gradle foi atualizada para 0.1.7.

Esta versão continua sendo fonte. A camada de integração ainda não contém um adaptador
concreto para DBC/JRMCore/DBC Additions; o comando `tree` apenas expõe a estrutura
interna que já está registrada.


## Novidades da v0.1.8

- Corrigida a importação de `Locale` no comando e a quebra de linha literal que
  havia sido introduzida no texto de ajuda da v0.1.7.
- Novo comando `/dragonascension progress <jogador>` mostra o domínio das evoluções
  da raça interna do jogador e sua faixa: Iniciante, Aprendiz, Experiente,
  Avançado ou Máximo.
- As faixas são somente classificações de exibição; não concedem domínio,
  desbloqueios ou transformações automaticamente.
- A versão do mod e do artefato Gradle foi atualizada para 0.1.8.


## Novidades da v0.1.9

- Criada a API `MasteryProgression.recordTransformationUse`, preparada para receber
  eventos confirmados de transformação de um adaptador DBC/DBC Additions.
- O progresso só é aplicado no servidor, para uma evolução existente e já desbloqueada.
- Cada chamada aceita no máximo 0,25 ponto de domínio e nunca ultrapassa 100.
- Não há ganho automático fictício: enquanto não existir um adaptador que confirme
  a forma ativa, o método não é chamado pelo mod.
- Novo comando `/dragonascension masteryinfo` explica o estado do sistema.
- Atualizados os metadados para 0.1.9.


## Novidades da v0.2.0

- Novo comando `/dragonascension check <jogador> <evolução>` faz uma prévia
  não-mutável dos requisitos de desbloqueio e informa o primeiro motivo que impede
  a evolução. Não altera domínio nem desbloqueia nada.
- A prévia respeita o adaptador externo quando registrado e não usa a raça manual
  como fallback se o adaptador estiver indisponível.
- `PlayerEvolutionData` normaliza raça interna para minúsculas com `Locale.ROOT`,
  valida IDs ao desbloquear/registrar treino/desafio e trata consultas nulas.
- Corrigida a versão exibida pelo diagnóstico e ampliada a lista de uso do comando.
- Atualizados os metadados para 0.2.0.

A prévia de desbloqueio usa a mesma validação da operação real. A integração concreta
com APIs de DBC/JRMCore/DBC Additions continua pendente de inspeção dos JARs e testes.


## Novidades da v0.2.1

- Criado `EvolutionUnlockService`, que centraliza a pré-validação e o desbloqueio
  efetivo no mesmo fluxo.
- `/dragonascension check` e `/dragonascension unlock` agora usam o mesmo serviço,
  evitando diferenças entre o que a prévia informa e o que a operação executa.
- O serviço bloqueia execução no lado cliente, IDs inexistentes e adaptadores
  registrados mas indisponíveis/sem raça verificável.
- A efetivação salva os dados somente depois que todos os requisitos passam.
- Atualizados os metadados para 0.2.1.


## v0.2.2 — sessões de transformação
A classe `TransformationSessionService` oferece uma API neutra para iniciar,
encerrar e consultar sessões de transformação confirmadas por um adaptador.
O domínio só é registrado por `recordConfirmedUse` enquanto a evolução
correspondente estiver marcada como ativa e desbloqueada. A detecção da forma
real ainda depende de um adaptador DBC/DBC Additions validado.
Consulte `VERIFICACOES_v0.2.2.txt` para limites e verificações desta versão.


## v0.2.3 — diagnóstico de API e sessões
O comando `/dragonascension compat` agora diferencia detecção do mod e visibilidade
de classes de entrada conhecidas. Isso é apenas uma sondagem inicial: não prova
compatibilidade de assinaturas. O comando `/dragonascension transformation [jogador]`
mostra a sessão registrada pelo Dragon Ascension e callbacks confirmados.
Consulte `VERIFICACOES_v0.2.3.txt` para limitações.


## v0.2.4 — segurança de sessões
Marcadores de transformação ativa agora são limpos ao entrar no servidor e
durante a clonagem do jogador após morte/respawn. O progresso permanente
(domínio, desbloqueios, treino, desafios e contador) é preservado. Isso evita
que uma sessão antiga seja tratada como forma ativa sem confirmação atual.
Veja `VERIFICACOES_v0.2.4.txt`.


## Novidades da v0.2.5

- `ITransformationAdapter` define o contrato opcional para um adaptador verificado
  informar qual evolução interna está ativa no jogador.
- `IntegrationManager` registra e consulta esse provedor com proteção contra falhas
  de APIs opcionais.
- `TransformationSessionService.synchronizeFromAdapter` reconcilia o estado salvo
  apenas no servidor e rejeita IDs desconhecidos.
- O contrato exige mapeamento para IDs internos do Dragon Ascension; IDs crus do DBC
  não são presumidos nem convertidos automaticamente.

Esta versão ainda não inclui um adaptador concreto nem chama APIs reais do DBC.
A integração só passa a funcionar quando um adaptador específico for implementado
e registrado. Build ForgeGradle e teste in-game não realizados.


## Novidades da v0.2.6

Foi adicionado `TransformationSyncEvents`, que consulta o `ITransformationAdapter`
registrado no fim do tick do jogador, uma vez por segundo e somente no servidor.
Sem adapter disponível, o listener não altera o estado. O adapter continua sendo
um componente externo: esta versão não contém uma implementação concreta para
DBC/JRMCore/DBC Additions e não presume IDs de formas desses mods.


## v0.3.0 — estabilização do núcleo

Esta revisão corrige erros de escape no bootstrap que impediam a compilação,
evita gravações NBT repetidas a cada polling e encerra sessões antigas quando
o adaptador informa forma desconhecida ou não desbloqueada. O diagnóstico de
compatibilidade também informa se há adaptador de transformação registrado e
qual provedor está ativo. Consulte `docs/INTEGRACAO_DBC.md` para o contrato de
integração. Ainda não há adaptador binário concreto para os mods externos.


## v0.3.1 — adaptador DBC Additions 1.8.10

Adicionado adaptador por reflection com assinaturas confirmadas nos JARs enviados.
Ele detecta formas customizadas conhecidas do DBC Additions e mapeia apenas as
combinações de nome/raça documentadas. Formas desconhecidas são ignoradas. A
integração ainda não cobre todas as formas nativas do DBC nem concede domínio
automaticamente. Veja `docs/INTEGRACAO_DBC.md`.


## v0.4.0 — integração JRMCore e domínio automático

- Detecta automaticamente a raça pelo JRMCore no login.
- Lê o nível a partir dos atributos por `getPlayerLevel(int[])` e a energia pela
  API individual do jogador.
- Registra 0,02 domínio por segundo apenas durante uma forma confirmada e
  desbloqueada pelo adaptador de DBC Additions.
- Formas nativas DBC sem mapeamento de estado validado continuam sem concessão
  automática de domínio.


## v0.4.1 — revisão

Revisão de imports e metadados após a integração automática de contexto JRMCore
e progressão de domínio da v0.4.0. Não altera as regras de progressão.


## v0.4.2 — comandos e diagnóstico

Textos dos comandos `compat`, `transformation` e `masteryinfo` atualizados para
refletir o comportamento real da integração da v0.4.x e deixar explícita a
limitação das formas nativas DBC sem mapeamento validado.


## v0.4.4 — correção

Correção de uma string multilinha inválida no diagnóstico `/dragonascension compat`.


## v0.4.5 — estados nativos DBC
A integração de transformações agora consulta primeiro as formas mapeadas do
DBC Additions e, quando não encontra uma correspondência, usa os nomes de estado
fornecidos pelo JRMCore para mapear transformações Saiyajin nativas conhecidas.
Estados sem evolução equivalente continuam ignorados. Consulte
`VERIFICACOES_v0.4.5.txt` para as assinaturas e limites verificados.


## v0.4.6 — diagnóstico de sincronização
O comando `/dragonascension transformation [jogador]` agora mostra separadamente
a sessão salva pelo Dragon Ascension, a forma externa reconhecida no momento e
o provedor do adaptador. Isso ajuda a distinguir uma falha de leitura externa
de uma sessão que ainda não foi sincronizada. O diagnóstico de domínio também
passa a descrever corretamente o adaptador composto.

A leitura externa não concede desbloqueios automaticamente: a evolução precisa
estar desbloqueada antes de o progresso de domínio ser registrado.


## v0.4.7 — consistência de versão e limites da integração nativa

Atualiza a versão declarada no `build.gradle` e na classe principal para
`0.4.7`, evitando que o JAR compilado anuncie uma versão antiga. A integração
nativa continua isolada por reflexão: se a assinatura esperada não existir na
instalação, o adaptador fica indisponível e o restante do mod pode iniciar.

A correspondência de nomes de transformação nativos ainda precisa ser
confirmada em execução no conjunto exato DBC/JRMCore instalado. Não considerar
os mapeamentos nativos como homologados apenas porque o projeto compila.


## v0.4.8 — validação central de IDs externos

A leitura de transformações externas agora passa por uma validação central: o ID
retornado por qualquer adaptador precisa existir na árvore registrada do Dragon
Ascension. IDs vazios, desconhecidos ou incompatíveis são descartados antes de
chegarem à sincronização de sessão e ao cálculo de domínio.

O diagnóstico de compatibilidade também deixa explícito que a leitura nativa
DBC permanece experimental até confirmação da assinatura e dos nomes retornados
no ambiente real. As formas mapeadas do DBC Additions continuam sendo a fonte
mais confiável de sincronização automática.


## v0.4.9
- Adicionadas as ramificações Saiyajin Oozaru → Oozaru Dourado → Super Saiyajin 4.
- Instinto Superior (Sinal) e Instinto Superior agora formam uma ramificação separada.
- Dados persistidos são filtrados contra o registro atual: IDs desconhecidos não são carregados como desbloqueios, treino, desafios ou domínio.
- Marcadores de transformação salvos só são mantidos se apontarem para uma evolução existente e desbloqueada.
- Os novos caminhos são definições de progressão; ativação visual, custo de energia e balanceamento em jogo ainda dependem da integração/runtime.


## v0.5.0
- Incluído teste independente de fumaça para o registro de evoluções, executável sem iniciar Minecraft/Forge.
- O teste verifica as 38 definições, distribuição por raça, integridade dos pré-requisitos, caminho Oozaru → Oozaru Dourado → SSJ4, ramificação separada do Instinto Superior e exclusividade Arcosiana de Black Freeza.
- Script: `verification/verify_registry.sh`. Isso valida a estrutura da árvore; não substitui compilação ForgeGradle nem teste dentro do jogo.

## v0.5.1
- Adicionada uma política independente para calcular o custo de energia por tick.
- O custo base é 1 ponto por tick e o domínio reduz gradualmente o custo até 50% no domínio máximo.
- Entradas inválidas e intervalos não positivos não geram custo.
- Incluídos testes isolados da política e um script para executar todas as verificações independentes.
- A política ainda não consome energia do JRMCore: isso depende de um adaptador que confirme a API real e a forma ativa no servidor.


## v0.5.2 — sincronização tri-state de transformações
- A leitura externa agora diferencia ACTIVE, INACTIVE e UNKNOWN.
- Falha de reflexão, API indisponível, forma desconhecida ou retorno nulo vira UNKNOWN e não encerra uma sessão previamente confirmada.
- Uma sessão só é encerrada quando o adaptador confirma INACTIVE; uma forma ACTIVE precisa continuar mapeada e desbloqueada.
- O adaptador composto prioriza qualquer forma ACTIVE e só confirma INACTIVE quando todos os adaptadores consultáveis concordam.
- Diagnóstico `/dragonascension transformation` diferencia forma ativa, estado normal confirmado e leitura indeterminada.
- Incluídos testes independentes do contrato tri-state e do adaptador composto.


## v0.5.3
- Proteção racial fail-closed: desbloqueios existentes só são reconhecidos como utilizáveis quando a raça atual é verificada e corresponde à raça da evolução.
- O início de uma sessão de transformação também exige correspondência racial atual.
- Se um adaptador de contexto foi registrado, mas está indisponível, o mod não recorre silenciosamente à raça salva.
- Adicionado teste de regressão para a validação racial nos desbloqueios e nas sessões.


## v0.5.4
- A sincronização da forma externa agora revalida a raça mesmo quando a evolução já consta como sessão ativa.
- O registro de domínio também revalida raça e desbloqueio antes de conceder progresso.
- Se a raça mudar ou não puder ser verificada, a sessão correspondente é encerrada e o domínio não é concedido.
- Teste de regressão ampliado para sincronização e progressão de domínio.

### v0.5.5
- Progressão salva agora é filtrada pela raça verificada: desbloqueios, treino, desafios e domínio de outra raça são removidos ao trocar de raça.
- Carregamento NBT aceita apenas progresso pertencente à raça registrada no próprio perfil.
- A sessão ativa incompatível é limpa durante a troca de raça.
- A integração real de energia JRMCore continua pendente de confirmação da API de escrita de energia; nenhum método externo foi presumido.

### v0.5.6 — ponte de cobrança de energia
- Adicionada a interface opcional `IPlayerEnergyAdapter` e o serviço `TransformationEnergyService`.
- A cobrança ocorre no servidor, em intervalos de 20 ticks, apenas para uma forma confirmada, desbloqueada e compatível com a raça.
- Sem um adaptador de energia explicitamente registrado, nenhuma energia é alterada e o domínio não progride por esse caminho.
- Não foi implementado um setter JRMCore por reflexão: a assinatura de escrita de energia ainda precisa ser confirmada contra a API exata instalada.


## v0.6.0 — efeitos internos e ponte experimental de energia

- Adicionado `JrmCoreEnergyAdapter`, que só se registra se encontrar as assinaturas
  `getInt(EntityPlayer,String)` e `setInt(EntityPlayer,String,int)`. Cada escrita é
  conferida por leitura posterior; se o valor não bater, o adaptador tenta restaurar
  o valor anterior. A assinatura de escrita ainda não foi confirmada no JRMCore
  1.3.51 desta sessão; portanto a ponte permanece experimental e fica desativada
  automaticamente quando a API não corresponde.
- Criado `TransformationEffectService`: formas ativas aplicam bônus próprios de
  dano de ataque e velocidade de movimento vanilla; os modificadores têm UUIDs
  exclusivos e são removidos ao sair da forma ou trocar de transformação.
- Efeitos são atualizados no servidor a cada 20 ticks. Estados externos `UNKNOWN`
  preservam os efeitos existentes até uma leitura confiável.
- `/dragonascension compat` agora informa se o adaptador de energia foi registrado.
- Adicionado teste isolado de compilação contra stubs e verificações de integração.

**Limites desta versão:** os bônus são atributos vanilla e não garantem alterar os
atributos internos de combate do DBC. Efeitos de aura/partículas ainda não foram
implementados. Não foi possível executar ForgeGradle completo nem teste in-game:
este ambiente não tem Gradle, JDK 8 nem os JARs de dependência carregados. Esta
versão continua sendo código-fonte, não um JAR instalável validado.


## v0.6.2 — endurecimento da ponte de energia
- A descoberta reflexiva da API JRMCore agora exige métodos estáticos compatíveis e retorno numérico na leitura.
- Resultado da descoberta (inclusive indisponibilidade) é armazenado para evitar repetir reflexão a cada verificação.
- Versão sincronizada entre `build.gradle`, anotação Forge e comando de diagnóstico.
- Teste isolado cobre consumo, energia insuficiente, jogador remoto e falha de confirmação.

A ponte continua experimental: o teste usa uma API simulada e não substitui a inspeção do JRMCore 1.3.51 real.


## v0.6.3 — limpeza de efeitos após rejeição de forma externa

- Corrigido um caso em que o adaptador confirmava uma forma ativa, mas Dragon
  Ascension a rejeitava por falta de desbloqueio ou incompatibilidade racial.
- A sessão anterior agora é encerrada como reconciliação concluída, permitindo
  que o evento de tick atualize os atributos e remova os modificadores antigos.
- O estado `UNKNOWN` continua preservando a sessão: falhas de leitura não são
  confundidas com uma forma ativa confirmada e inválida.
- Adicionado teste de regressão estático para a limpeza dos efeitos após rejeição.

A compilação completa e os testes no Minecraft 1.7.10 continuam pendentes.


## v0.6.4 — robustez da cobrança reflexiva de energia

- A cobrança lê o saldo, verifica suficiência, grava o novo valor e confirma a leitura.
- Se a gravação ou a leitura de retorno falhar, tenta restaurar o saldo anterior.
- Novo teste isolado `JrmCoreEnergyAdapterSmokeTest` cobre cobrança válida, saldo insuficiente, escrita ignorada e bloqueio no lado cliente.
- O teste usa classes simuladas e não substitui a inspeção do JRMCore 1.3.51 real.


## v0.6.6 — verificação de rollback da energia

- A rotina de recuperação após falha agora compara o saldo restaurado com o saldo original.
- O teste de integração simulada inclui o cenário em que o setter altera a energia e, em seguida, lança uma exceção.
- O teste confirma que o adaptador informa falha e restaura o saldo anterior nesse cenário.
- Isso não comprova que o método `setInt` do JRMCore oficial tenha a mesma semântica; a ponte segue experimental até ser validada com o JAR 1.3.51.


## v0.6.6 — teste de execução dos efeitos

- Adicionado teste isolado para aplicação, substituição e limpeza dos modificadores de ataque/velocidade.
- Confirmado que a atualização substitui os modificadores próprios sem duplicá-los.
- Confirmado que `clear` remove os modificadores do Dragon Ascension e que o serviço não altera atributos no lado cliente.
- Os testes usam stubs do Minecraft e não substituem um teste real no Forge 1.7.10.


## v0.7.1 — partículas de aura
- Implementado `TransformationAuraService` com seleção de partículas por família de transformação.
- A emissão ocorre apenas no servidor, a cada 5 ticks, e exige um ID ativo não vazio.
- A implementação usa partículas vanilla do Minecraft 1.7.10; não inclui animações customizadas nem texturas próprias.
- Teste isolado valida o mapeamento e os bloqueios de lado/estado; confirmação visual in-game continua pendente.


## v0.7.1 — broadcast de partículas no servidor

- A aura usa o método de broadcast `WorldServer.func_147487_a` esperado no Minecraft 1.7.10, localizado por reflexão para manter a dependência opcional.
- O método encontrado é armazenado em cache por classe de mundo.
- Se a API não estiver disponível, a emissão falha sem tentar executar efeitos no lado cliente.
- O teste isolado agora valida a chamada de broadcast em um stub com a assinatura 1.7.10 esperada.


## v0.7.1 — compatibilidade MCP/SRG do broadcast de aura

- A descoberta reflexiva do método de partículas agora tenta `func_147487_a` (SRG) e `spawnParticle` (MCP).
- Isso cobre os nomes comuns em runtime de produção e em ambientes de desenvolvimento Forge 1.7.10, sem assumir que uma string reflexiva será remapeada pelo Gradle.
- O teste de aura valida os dois nomes usando mundos simulados separados.
- Os scripts de verificação são incluídos com permissão de execução para que `verification/verify_all.sh` funcione após extrair o ZIP.
- Ainda é necessário validar no servidor Minecraft real; os testes usam stubs.


## v0.7.1 — efeitos apenas para evoluções registradas

- `TransformationEffectService` agora consulta `EvolutionRegistry` antes de aplicar bônus.
- IDs desconhecidos ou definições desativadas não recebem modificadores.
- A limpeza dos modificadores próprios acontece antes da validação, então um ID inválido também remove bônus antigos.
- Teste de regressão cobre ID inválido, troca para uma forma válida e limpeza.
- Isso protege contra valores de sessão salvos/corrompidos e chamadas internas com IDs arbitrários; não substitui a validação racial e de desbloqueio da sessão.
