# Compilar Dragon Ascension (Minecraft 1.7.10)

## Requisitos

- ForgeGradle GTNH 1.2.11 via JitPack (configurado no build.gradle), mantendo as dependências transitivas declaradas pelo plugin.

- JDK 8 (não Java 17/21).
- Gradle 6.9.1.
- Conexão com a internet na primeira execução: A variante GTNH do ForgeGradle 1.2 baixa o Forge/Minecraft e dependências de build. O primeiro build exige internet.
- Projeto configurado para Forge `1.7.10-10.13.4.1614-1.7.10`.

O código usa as APIs do Minecraft/Forge em tempo de compilação. As integrações com JRMCore e DBC Additions são feitas por reflexão; os JARs desses mods não precisam ser adicionados ao classpath para compilar esta versão.

## Windows

1. Instale JDK 8 e Gradle 6.9.1.
2. Abra a pasta do projeto.
3. Execute `BUILD_WINDOWS.bat`.
4. Se terminar sem erros, procure `build/libs/DragonAscension-<versão-do-build.gradle>.jar`.

## Linux

1. Selecione JDK 8 como `JAVA_HOME` e no `PATH`.
2. Instale Gradle 6.9.1.
3. Execute `./build-linux.sh`.
4. Se terminar sem erros, procure `build/libs/DragonAscension-<versão-do-build.gradle>.jar`.

## Compatibilidade do Gradle

O fork GTNH do ForgeGradle 1.2.11 é usado para corrigir o download legado do Minecraft 1.7.10. Esta configuração fixa Gradle 6.9.1 e JDK 8; não misture com Gradle 4.4.1 do ForgeGradle original. O fork GTNH suporta a linha Gradle 6.9.1, enquanto o ForgeGradle original 1.2 é limitado a Gradle 4.4.1.

## Diagnóstico

- O script executa `gradle help --stacktrace` antes de preparar o workspace, para separar erros de configuração/resolução de dependências dos erros de compilação.

- O projeto usa o fork GTNH do ForgeGradle 1.2 para contornar falhas antigas do download do Minecraft no ForgeGradle original.

- `Unsupported class file major version` ou erro de runtime do Gradle: verifique se o processo está usando JDK 8.
- Falha ao resolver `com.github.GTNewHorizons:ForgeGradle:1.2.11` via JitPack ou artefatos Forge: verifique internet, DNS, proxy e repositórios Maven.
- Erros de compilação Java: guarde a saída completa do terminal; ela identifica o arquivo/linha a corrigir.

## Limite da validação

Os scripts verificam os pré-requisitos e executam as tarefas de preparação e build. Os scripts leem a versão diretamente de `build.gradle`, então o nome esperado do JAR acompanha futuras atualizações sem precisar editar os scripts. A existência do JAR só deve ser considerada confirmada depois de a tarefa terminar com sucesso e o arquivo aparecer em `build/libs/`. Ainda é necessário testar o mod em uma instância Minecraft 1.7.10 com Forge e as versões compatíveis dos mods-alvo.
